#!/bin/sh
#
# a test sequence for the options EXITCOORD and CFILE.
#
# fluxtest1, fluxtest2, fluxtest3 produce output for depth intervals
# 0-600, 600-1200, and 1200-1800 angstroms, respectively.
# fluxtest2 and fluxtest3 take the exitcoordinates of the
# preceding fluxtest1 and fluxtest2 as inputs.
#
# fluxtest0 produces output for the whole region 0-1800 angstroms.
# Thus exit coordinates of fluxtest0 and fluxtest3 should be equivalent.
# (Note that the flux is not the same, since it is an average over
#  intervals 0-1800 and 1200-1800, respectively)
#
BIN=../BIN
#
./fluxtt
#
$BIN/makeflx -p $BIN/fluxhf fluxtesti
../BIN/plotxy fluxtesti.txt <<EOI
py_y1.ps
xcoord
no
100 100
5 3
-0.2 0.2 -1 5
5
-0.2 0.2 -1 5
angle to [001] plane (deg)
distance from [011] plane
fluxtesti:  0.1 nm
0
3
0 40
1
-1
EOI

$BIN/makeflx -p $BIN/fluxhf fluxtest1
../BIN/plotxy fluxtest1.txt <<EOI
py_y1.ps
xcoord
no
100 100
5 3
-0.2 0.2 -1 5
5
-0.2 0.2 -1 5
angle to [001] plane (deg)
distance from [011] plane
fluxtest1:  60 nm
0
3
0 40
1
-1
EOI

$BIN/makeflx -p $BIN/fluxhf fluxtest2
../BIN/plotxy fluxtest2.txt <<EOI
py_y2.ps
xcoord
no
100 100
5 3
-0.2 0.2 -1 5
5
-0.2 0.2 -1 5
angle to [001] plane (deg)
distance from [011] plane
fluxtest2: 120 nm
0
3
0 40
1
-1
EOI

$BIN/makeflx -p $BIN/fluxhf fluxtest3
../BIN/plotxy fluxtest3.txt <<EOI
py_y3.ps
xcoord
no
100 100
5 3
-0.2 0.2 -1 5
5
-0.2 0.2 -1 5
angle to [001] plane (deg)
distance from [011] plane
fluxtest3: 180 nm
0
3
0 40
1
-1
EOI

$BIN/makeflx -p $BIN/fluxhf fluxtest0
../BIN/plotxy fluxtest0.txt <<EOI
py_y0.ps
xcoord
no
100 100
5 3
-0.2 0.2 -1 5
5
-0.2 0.2 -1 5
angle to [001] plane (deg)
distance from [011] plane
fluxtest0: 180 nm
0
3
0 40
1
-1
EOI

./pltpy_y

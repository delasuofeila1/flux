import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from functools import partial
import datashader as ds
from datashader.mpl_ext import dsshow
import pandas as pd
import mpl_scatter_density
from scipy.ndimage import gaussian_filter
from scipy.stats import gaussian_kde
import matplotlib.cm as cm
import glob
import os
import imageio as io
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.cm as cm


file_list = glob.glob('/home/omadsim/flux7.9.6/FLUX7/INPUT/NewFolder600/database/0.1000_120.0.txt',recursive = True) # Get all the pngs in the current directory

for filename in file_list:
    with open(filename) as f:
        f=f. readlines()[0:512]
        arrays = [list(map(float, line.split(' ')[0:512])) for line in f]
        A=np.concatenate([np.array(i) for i in arrays])
        b = np.reshape(A,(512,512))
        b=gaussian_filter(b, sigma=0)
        plt.imshow(b,cmap=mpl.cm.nipy_spectral,norm = mpl.colors.Normalize(vmin=0, vmax=100))
        plt.colorbar()
        name=filename.split('database/')[1].split('.txt')[0]
        plt.savefig('data622_0_picture/'+name+'0,1.png')
        plt.clf()


make
time makeflx -p flux7 bigjob
bigshow.sh


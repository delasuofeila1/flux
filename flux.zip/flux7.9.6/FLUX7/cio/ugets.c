/* @(#)ugets.c          29/05/97 09:48 */
/*============================= ugets ===============================*/
/* substitute for fgets, for unix, msdos, as well as os9 files */

#ifndef cio_h
#include <cio/cio.h>
#endif /* cio_h */

#ifdef unix
#include <errno.h>
#endif /* unix */

char *ugets(ptr,cnt,fp)
char *ptr;
int4 cnt;
FILE *fp;
{ register int c=1;
  int nc;
  register char *pt;

#ifdef os9
extern int menu_open;
if(menu_open)
{
  if(fp->_ptr == fp->_end)
  while( _gs_rdy(fileno(fp)) < 0) sleep(1);
}
#endif /* os9 */

  pt=ptr;
  while (--cnt)
  { 
    c=getc(fp);
    if((c==EOL0) || (c==EOL1)) { *pt++ = EOL0; break;}
    if(c < 0 || c==EOF)
    {
      *pt++ =0;
      ptr=NULL;
      clearerr(fp);

#ifdef os9
/* prevent endless looping on eof (=escape key) in os9: */
      cleareof(fp);
#endif /* os9 */

      break;
    }
    *pt++ = c;
  }
  if(cnt > 0) *pt = 0;

  /* test if CR followed by LF */
  /* not done if interactive because of the extra 'getc' */
  if(fp != stdin)
  { if(c==EOL0 || c==EOL1)
    { nc=getc(fp);
      if( nc < 0 || nc == EOF)
      {
        clearerr(fp);
  
#ifdef os9
        cleareof(fp);
#endif /* os9 */
  
      }
      else
      { /* push back if not CRLF or LFCR */
        if( (nc != EOL1 && nc != EOL0) || nc == c ) ungetc(nc,fp);
      }
    }
  }
  return(ptr);
}
/*============================= ufopen ===============================*/
#ifdef MS_DOS
/* MS_DOS text mode is not our cup of tea          */
/* Use binary as a rule and let ugets handle EOL's */
FILE *ufopen(filename,mode) char *filename, *mode;
{ char bmode[10];
  strcpy(bmode,mode);
  strcat(bmode,"b");
  return fopen(filename,bmode);
}
#endif

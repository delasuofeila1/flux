/* @(#)substenv.c       01/05/97 09:23 */
#ifndef cio_h
#include <cio/cio.h>
#endif /* cio_h */

/*=========================  substenv  ========================*/

int4 substenv(text,maxlen)
char *text;
int4 maxlen;
/* find substrings starting with the symbol $, and try to   */
/* substitute environmental variable.                       */
/* substenv fails if the variable name contains one or more */
/* non-alphanumeric characters (with the exception of '_')  */

{ register char *in,*out,*env=NULL;
  char *getenv();
#ifdef CIOVARS
  VARIABLE *var;
  int4 stat;
#endif
  int4 ier=0;
  int nn,dn;
  char substring[LINE_LEN],*format;
  int4 len, ipt, ianswer, term;
  double fanswer;

#ifdef DEBUGv
  sput3("substenv,ier=%lx, in:%s\n",ier,text);
#endif /* DEBUGv */
  in=text;
  while((in=strchr(in,'$'))!=NULL)
  {
    env= NULL;
    out= in; ++out;
    while ((isalnum(*out)) || *out == '_')++out;
    nn= (size_t)(out-(in+1));
/* in points to $,
   out points to the first non-alphanumeric after $
*/
    if(nn >= LINE_LEN) ier= ( errstat | syntaxerr);
    else
    if (nn > 0)
    {
#ifdef CIOVARS
      ipt=1;
      len= text + (size_t)maxlen - in;
      stat= evalvar(in,&len,&ipt,&var,substring, &term);
      if(stat==0 &&  (var->type == 'c'))
      { env=var->valpt;
        out=in+(size_t)ipt-1;
      }
      else
#endif /* CIOVARS */
      {
        strncpy(substring,in+1,(size_t)nn);
        substring[nn] = '\0';
        env= getenv(substring);
      }
      if (env) /* CIOVAR or environmental variable */
      {
        *in='\0'; /* wipe out the $ */
        nn=strlen(env);
        if(nn > LINE_LEN-1) { nn= LINE_LEN-1; ier|= (errstat|truncaterr); }
        strncpy(substring,env,(size_t)nn);
        substring[nn] = '\0';
      } /* endif env */
    }
    else /* nn == 0 */
    if ( *out == '(' )  /* $ followed by ( */
    {
      ipt= 1;
      len= text + (size_t)maxlen - out;
      ier= substenv(out,len); /* recursive call substenv() */
      if(ier & errstat)break;
      fanswer=DNOTHING;
      ier= evalxp_(out,&len,&ipt,&ianswer,&fanswer,&term);
      if (fanswer > DNOTHING)
      {
        ier &= ~(illterm|delimiterr|errstat);
        if(ier <= notinteger)ier=0; else ier |= errstat;
        out += (size_t)ipt-1;
        *in='\0'; /* erase that $ */
        in=out;
        while( (*out != ')') && (*out)) out++;
        *out = '\0';
        ++out;
        if(term == ')')
        { /* take default format */
          format= "%.7g ";
        }
        else
        { /* user supplied format */
          if(term == ',')++in;
          format= in;
        }
        sprintf(substring,format,fanswer);
        env= substring;
        nn=strlen(substring);
      } /* end if fanswer > DNOTHING */
    }   /* end if $ followed by '(' */
    if(env) /* $ sequence to be replaced by substring */
    { dn=strlen(out);
      if(nn+dn > LINE_LEN-1) {dn= LINE_LEN-1-nn; ier|= (errstat|truncaterr); }
      strncat(substring,out,(int)dn);
      nn+= dn;
      substring[nn]= '\0';
      dn=strlen(text);
      if(nn+dn > maxlen) {nn= (size_t)maxlen-dn; ier|= (errstat|truncaterr); }
      strncat(text,substring,(int)nn);
      nn+= dn;
      text[nn]= '\0';
    }
    else
    ++in; /* prevent endless looping when $ not replaced by something */
  }
#ifdef DEBUGv
   sput3("substenv,ier=%x,out:%s\n",ier,text);
#endif /* DEBUGv */
  return(ier);
}

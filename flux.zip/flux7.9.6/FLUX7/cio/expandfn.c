/* @(#)expandfn.c       27/05/04 16:55 */
/* ================== expandfn ================================== */
#include <cio/cio.h>

#ifdef MINGW
#undef unix
#define MS_DOS
#endif

#ifdef unix
#include <pwd.h>
#endif /* unix */

char *strslash(p)
char *p;
{ /* find the next occurence of a SLASH in string p */
  char *q;
#ifdef SLASH2
  char *q2;
#endif

  q = strchr(p,SLASH);
#ifdef SLASH2
  q2= strchr(p,SLASH2);
  if(!q)q=q2;
  else if((q2) && (q2<q))q=q2;
#endif
  return q;
 }


char *expandfn(path)
char *path;
/* expand filenames. In string path the following are substituted:
   $<environment var>
   ~<user>, when ~ is the first char of string path.
   Substrings are terminated by a null byte, or by a slash.
   Difference with normal shell behaviour:
   If $<string> or ~<string> cannot be resolved it is left
   unmodified, and no error or or warning is given.

   The return value is a pointer to a static array, that remains
   available until the next call of expandfn.

   To get in place file name substitution, use void fexpandfn(path)
 */
{
  char tmppath[LINE_LEN], tail[LINE_LEN], *p, *q, *t;
  static char newpath[LINE_LEN];

  newpath[LINE_LEN-1]=0;
  strncpy(newpath,path,LINE_LEN-1);
  p = newpath;
  /* expand environment variables */
  while ((p = strchr(p,'$'))!=NULL)
  { *p = '\0';
    ++p;
    if((q= strslash(p))!=NULL){ strncpy(tail,q,LINE_LEN-1); *q = '\0'; }
    if((t= getenv(p))!=NULL) strncpy(tmppath,t,LINE_LEN-1);
    else { tmppath[0]= '$'; strncpy(&tmppath[1],p,LINE_LEN-2); }
    if(q) strncat(tmppath,tail, LINE_LEN-1-strlen(tmppath));
    strncat(newpath, tmppath, LINE_LEN-1-strlen(newpath));
  }

  /* expand ~ and ~user */
  if( *(p = newpath) == '~')
  { ++p;
    if((q= strslash(p))!=NULL){ strncpy(tail,q,LINE_LEN-1); *q = '\0'; }
    if(*p)
    {
    /* ~user */
#ifdef unix
      if( getpwnam(p)) strncpy(tmppath, getpwnam(p)->pw_dir, LINE_LEN-1);
      else { tmppath[0]= '~'; strncpy(&tmppath[1],p,LINE_LEN-2); }
#else
#ifdef os9
      strcpy(tmppath,"/dd/USERS/");
#endif /* os9 */
#ifdef MS_DOS
    /* ~user not implemented for MS_DOS */
      strcpy(tmppath,"~");
#endif /* MS_DOS */
      strncat(tmppath,p,LINE_LEN-11);
#endif /* unix */
    }
    else /* ~ without user name */
      strncpy(tmppath,expandfn("$HOME"),LINE_LEN-1);
    if(q) strncat(tmppath,tail, LINE_LEN-1-strlen(tmppath));
    strncpy(newpath, tmppath, LINE_LEN-1);
  }

  /* expand leading './' */
  if( *(p = newpath) == '.')
  { ++p;
    if((q= strslash(p))==p)
    { strncpy(tail,q,LINE_LEN-1);
      t=getcwd(newpath,LINE_LEN-1); /* assign to keep compiler happy */
      strncat(newpath,tail, LINE_LEN-1-strlen(newpath));
    }
  }
  return newpath;
}
/* ================== fexpandfn ================================== */
void fexpandfn(filnam)
char * filnam;
{
  strcpy(filnam, expandfn(filnam));
}

/* ================== standalone ================================== */
#ifdef standalone
main(argc,argv)
int argc;
char **argv;
{ while (++argv, --argc)
  { sput2("old: %s\n", *argv);
    sput2("new: %s\n", expandfn(*argv));
    newline();
  }
}
#endif

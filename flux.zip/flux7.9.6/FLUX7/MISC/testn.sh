track <<EO 
file
motrack0.ps
motrack0.txt
y
-1 4 -1 4
y
EO

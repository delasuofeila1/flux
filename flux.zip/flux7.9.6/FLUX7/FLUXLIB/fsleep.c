/* @(#)fsleep.c        21/12/97 14:15 */
#include <unistd.h>
#include <stdio.h>
#ifdef _MINGW
#include <windows.h>
#endif
/* in MINGW use Microsoft's Sleep() else C-language sleep() */
/* =======================  fsleep  ======================= */
/* wait a few seconds */
#ifdef f77_UNDERSCORE_AFTER
#define fsleep fsleep_
#endif
void fsleep(seconds)
int *seconds;
{ 
#ifndef _MINGW
  sleep((unsigned int) *seconds);
#else
  Sleep((unsigned int) *seconds * 1000);
#endif
}

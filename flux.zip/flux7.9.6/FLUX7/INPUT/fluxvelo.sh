#!/bin/sh
# sort of benchmark. turn around times for some systems:
#
# computer             F77  FLAGS    time(user+sys) date
#                                     s      h
# SGI IP22      Unix   f77  -O2      52775  14.7    
# HP 720        Unix   f77  +O3      41326  11.5    1990
# Pentium-233MX Linux  g77  -O2      13812   3.84
# HP C180       Unix   f77  +O2      10274   2.85   1995
# HP C180       Unix   f77  +O4 +)    7801   2.17
# Pentium4 2.7G Linux  g77  -O3 ++)    960   0.27   2004
# Intel i5-2500 Linux  gfort-O3 +++)    84   0.023  2013

# +) 'profile  based' optimization
# ++) gcc/g77 version 3.4.1
# +++) 64-bit gfortran version 4.7.2, 4 CPU's at 3.3GHz

cat >batflux.ini <<einde
fluxvelo.inp                                                        
fluxvelo.fla                                                        
fluxvelo.log                                                        
fluxvelo.yld                                                        
 1
 1
NEW
einde
rm -rf fluxvelo.fla fluxvelo.log
starttime=`date +"%s"`
time ../BIN/fluxhf
stoptime=`date +"%s"`
echo "this job took `expr $stoptime - $starttime` seconds"

rm -f sleeptest.exe sleeptest.o
make sleeptest.exe
time sleeptest.exe
time sleeptest.exe

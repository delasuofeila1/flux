#include <stdio.h>
#include <string.h>

/* reads a line of max ntxt characters from stdin
 * returns the number of characters read
 * excluding newline which is replaced by '\0'
 * end-of-file condition is represented by the character '&'
 */

int readcc_(char *txt, int ntxt)
{
  char* p;
  p=txt;
  while(--ntxt)
  {
    *p= getchar();
    if(*p == '\n')break;
    if(*p==EOF)
    { 
      *p='&';
      p++;
      break;
    }
    p++;
  }
  *p='\0';
  return strlen(txt);
}

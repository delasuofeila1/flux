/* @(#)gettime.c        06/12/97 14:15 */
#include <time.h>
#include <stdio.h>
#include <string.h>
/* ======================== get_the_time ======================= */
static time_t start_time=0;
double time_since_start;

void get_the_time(day,month,year,hour,minute,second)
long int *day,*month,*year,*hour,*minute,*second;
/* get the local date and time in the 6 integers */
/* pointed to by the arguments */
{
  struct tm *localtime(), *ltm;
  time_t now;
  now = time((time_t*)0);
  if( start_time == (time_t)0 ) start_time=now;
#ifdef sun
  /* sun does not have difftime(), so forget it */
  time_since_start = 0.0;
#else
  time_since_start = difftime( now, start_time);
#endif
  ltm = localtime ( &now );
  *day   = (long int) ltm->tm_mday;
  *month = (long int) (1 + ltm->tm_mon);
  *year  = (long int) ltm->tm_year;
  *hour  = (long int) ltm->tm_hour;
  *minute= (long int) ltm->tm_min;
  *second= (long int) ltm->tm_sec;
}
/* =======================  fdate_  ======================= */
/* write the local date and time to CHARACTER*20 datestring */
/* for Fortran: not zero-terminated, but padded with spaces */
#ifdef f77_UNDERSCORE_AFTER
#define fdate fdate_
#endif
void fdate(datestring)
char datestring[20];
{ long int day,month,year,hour,minute,sec;
  void get_the_time();
  int i;

  get_the_time(&day,&month,&year,&hour,&minute,&sec);
  sprintf(datestring,"%02ld/%02ld/%02ld %02ld:%02ld %.0f",
   day, month, year, hour, minute, time_since_start);
  for(i=strlen(datestring);i<20;i++) datestring[i]= ' ';
}

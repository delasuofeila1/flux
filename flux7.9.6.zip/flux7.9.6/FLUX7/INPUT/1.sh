fluxgo -p fluxzbl testall1
sed -i -e '/too/d' testall1.txt
sed -i -e '/!/d' testall1.txt
python shabi.py 
python plot2.py

#!/bin/sh

cat >batflux.ini <<einde
fluxvel.inp                                                        
fluxvel.fla                                                        
fluxvel.log                                                        
fluxvel.yld                                                        
 1
 1
NEW
einde
rm -rf fluxvel.fla fluxvel.log
time ../flux7

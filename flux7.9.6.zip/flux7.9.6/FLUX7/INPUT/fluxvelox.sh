#! /bin/sh
#
#simulate case described in fluxvelox.inp:
makeflx fluxvelox
#
#plt some results, first raw data, then smoothed
plotxy fluxvelox.txt<<EOI
fluxvelox.ps
xcoord
normal
100 100
2 3
0 3.8 0 3.8
5
0 3.8 0 3.8
x
y
flux at depth 500
1
3
0 10
1
4
-10000 -30 60 120 120
0 20 10 10 10
10 1 1 20
1 1 100 100
1
flux at depth 500
6
6
4
/
/
/
/
1
Flux at depth 500, smoothed
3
/
1
0
0
EOI

# call PostScript viewer
gv fluxvelox.ps &
exit

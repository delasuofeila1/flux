/* @(#)intarg.c         18/03/98 11:41 */
#ifndef cio_h
#include <cio/cio.h>
#endif /* cio_h */
/*======================== intarg ======================== */
void intarg(number,prompt,nprompt)
int4 *number;
int nprompt;
char *prompt;
/* ask an integer number, result in *number */
/* Fortran callable alternative of getint    */
{ int4 stat;
  stat = getint ( sprompt(prompt,nprompt), number, true );
  if (stat & Qstat) eruit("",NULL);
  if (stat & errstat)
  { printerr(stat);
    eruit("intarg: error in number",NULL);
  }
}

/*========================= dparg ========================= */
void dparg(dnumber,prompt,nprompt)
double *dnumber;
int nprompt;
char *prompt;
/* ask a double precision number, result in *dnumber */
/* Fortran callable alternative of getreal    */
{ int4 stat;
  stat = getreal ( sprompt(prompt,nprompt), dnumber, true );
  if (stat & Qstat) eruit("",NULL);
  if (stat & errstat)
  { printerr(stat);
    eruit("dparg: error in number",NULL);
  }
}

/*======================== realarg ========================*/
void realarg(number,prompt,nprompt)
float *number;
int nprompt;
char *prompt;
/* ask a real number (single precision float), result in *number */
/* Fortran callable alternative of getreal    */
{ double R;
  R= *number;
  dparg(&R, prompt, nprompt);
  *number = R;
}

/*======================== txtarg ========================*/
void txtarg(text,prompt,ntxt,nprompt)
int ntxt, nprompt;
char *text,*prompt;
/* Fortran callable alternative of get_text */
{
  int4 stat;
  int ntext;

  ntext=ntxt;
  stat = get_text ( sprompt(prompt,nprompt), text, ntext, false );
  if (stat & errstat)
  {
    printf("txtarg: error %s while reading from stdin\n",printerr(stat));
    exit(-1);
  }
  while ( (--ntext >= 0) && (*(text+ntext) < ' ')) *(text+ntext) = ' ';
}

/*======================== linearg ========================*/
void linearg(text,prompt,ntxt,nprompt)
int ntxt, nprompt;
char *text,*prompt;
/* Fortran callable alternative of get_line */
{
  int4 stat;
  int ntext;

  ntext=ntxt;
  stat = get_line ( sprompt(prompt,nprompt), text, ntext, false );
  if (stat & errstat)
  { printerr(stat);
    eruit("linearg: error",NULL);
  }
  while ( (--ntext >= 0) && (*(text+ntext) < ' ')) *(text+ntext) = ' ';
}
#ifdef CIOVARS
/*========================== fgetvar  ========================*/
#ifndef cio_h
#include <cio/cio.h>
#endif /* cio_h */

int4 fgetvar(prompt,V,name,fdefault,nprompt)
char *prompt;
VARIABLE **V;
Varname name;
int4 *fdefault;
int nprompt;
/* Fortran interface for getvar: fdefault is pointer to int4 */
{ 
  return getvar(sprompt(prompt,nprompt),V,name,*fdefault);
}
#endif

/* @(#)eruit.c          17/06/97 12:16 */
/*=========================  eruit  =========================*/
#include <cio/cio.h>

void ciobeg(cioreset)
void(*cioreset)();
{
  /* where to go after cio errors */
  CIO_RECOVER= cioreset;
}

void eruit(control_string,pointer)
char control_string[];
char *pointer;
/* eruit: print an error message and return to main() via longjmp */
/*        control_string: a control string, suitable for printf(),*/
/*                        containing at most 1 %format descriptor */
/*        pointer       : the second argument for printf()        */
/* ieruit: the same, but now second argument for printf(0 is int  */
/* april 2012: ieruit eliminated, not used anyways, questionable code */
{ extern int ncontext,ercontext,ercontrolpt;
  int i;
  if(ncontext < maxcontexts) pushcontext();
  ercontext=ncontext;
  pushc(&breakflag,1);
  ercontrolpt=controlpointer;
  controlpointer=Ncontrolstack-1;
  breakflag=false;
  if(control_string)
  { 
#ifdef CIOVARS
    varcleanup(1);
#endif /* CIOVARS */
    VARLEVEL=1; ercontext= -1;  /* no continue */
    newline();
    for(i=0;i<INPUTlen;++i)
     if (INPUTline[i])
      { sput2("%c",INPUTline[i]); }
    newline();
    for(i=2;i<INPUTpt;++i){sput1("."); }
    sput1("^      ");
    if(*control_string)
    { sput2(control_string,pointer); }
    newline();
/*    if(! INTERACTIVE[0]) cio_stop(); */
  }
/*  if(INPUTlen > 2 && INPUTline[INPUTlen-1]=='!')wr_gui("\n"); */
#ifndef IGNORE_ALTIO
  flushdefs();
#endif
  while (ncontext>0)
  { popcontext();
  }
  INPUTEOL=true;
  if(CIO_RECOVER) 
  { (*CIO_RECOVER)();
    exit(0); /* not supposed to return */
  }
  longjmp(environment,-1);
}
/*
void ieruit(control_string,value)
char *control_string;
int4 value;
{ 
  eruit(control_string, (char *)value);
}
*/
/*=======  pushcontext/rstcontext/popcontext/dumpcontext  =========*/
void pushcontext()
{ extern CONTEXT contexts[];
  extern int ncontext;
  register int i;
#ifdef DEBUG
  sput3("pushcontext, INPUTchpt= %8lx, INPUTline= %s\n",INPUTchpt, INPUTline);
#endif /* DEBUG */
  if(ncontext>=maxcontexts) eruit("context stack overflow!",NULL);
  contexts[ncontext].vcharpt=INPUTchpt;
  contexts[ncontext].inputpt=INPUTpt;
  contexts[ncontext].inputlen=INPUTlen;
  contexts[ncontext].inputeol=INPUTEOL;
  contexts[ncontext].inputeok=INPUTEOK;
  contexts[ncontext].cmdline=CMDLINE;
  contexts[ncontext].varlink=VARLINK;
  contexts[ncontext].forindex=FORINDEX;
  contexts[ncontext].repcount=REPCOUNT;
  for(i=0;i<INPUTlen;++i)
  contexts[ncontext].inputline[i]=INPUTline[i];
  ++ncontext;
}

void rstcontext(newcntxt) int newcntxt;
{ /* restore context as for ncontext=newcntxt (must be >0) */
  extern int ncontext;
  ncontext=newcntxt;
  popcontext();
}

void popcontext()
{ extern CONTEXT contexts[];
  extern int ncontext;
  register int i;
  if(ncontext<=0) eruit("context stack underflow!",NULL);
  --ncontext;
  INPUTchpt=contexts[ncontext].vcharpt;
  INPUTpt=  contexts[ncontext].inputpt;
  INPUTlen= contexts[ncontext].inputlen;
  INPUTEOL= contexts[ncontext].inputeol;
  INPUTEOK= contexts[ncontext].inputeok;
  CMDLINE=  contexts[ncontext].cmdline;
  for(i=0;i<INPUTlen;++i)
  INPUTline[i]=contexts[ncontext].inputline[i];
  INPUTline[INPUTlen]='\0';
#ifdef DEBUG
  sput3("popcontext, INPUTchpt= %8lx, INPUTline= %s\n",INPUTchpt, INPUTline);
#endif /* DEBUG */
  FORINDEX =contexts[ncontext].forindex;
  REPCOUNT =contexts[ncontext].repcount;
}

void dumpcontext()
/* forget last previous pushed context */
{ extern CONTEXT contexts[];
  extern int ncontext;
  if(ncontext<=0) eruit("context stack underflow!",NULL);
  --ncontext;
}
/*=========================  pushc/popc  =========================*/
void pushc(item,nbytes)
char item[];
int nbytes;
/* push nbytes of item onto controlstack */
{ int nbyte; nbyte=nbytes;
  if(controlpointer<nbytes) eruit("control stack overflow",NULL);
  if(controlpointer>=Ncontrolstack)eruit("control stack underflow",NULL);
  while(nbyte>0)
  { controlstack[controlpointer--]=item[--nbyte]; }
    controlstack[controlpointer--]=nbytes;
}

void popc(item,nbytes)
char item[];
int nbytes;
/* pop nbytes from controlstack into item */
{ int nbyte;
  if((++controlpointer>=Ncontrolstack)
   || (controlstack[controlpointer]!=nbytes))
  { --controlpointer; eruit("control stack corrupted",NULL); }
  nbyte=0;
  while(nbyte<nbytes)
  { item[nbyte++]= controlstack[++controlpointer]; }
  if(controlpointer>=Ncontrolstack)eruit("control stack underflow",NULL);
}

int lookc()
/* look in controlstack without modifying it
   return the item pushed on, or '\0' */
{ int mypointer;

  if(controlpointer>=Ncontrolstack-1)return 0;
  mypointer= controlpointer;
  ++mypointer;
  mypointer += controlstack[mypointer];
  if(mypointer>=Ncontrolstack)return 0;
  return (int) controlstack[mypointer];
}
#ifdef CIOVARS
/*==========================  poesje ============================*/
void poesje(varptr)
char *varptr;
/* varptr points to the text of a 'CIO program' to be processed */
{ pushcontext(); /* push context and process char variable */
  pushc("v",1);  /* also put a marker in the control stack */
  INPUTchpt=varptr;
  INPUTlen=0; /* force getting a new line */
  ++VARLEVEL;
}
/*=========================  varcleanup =========================*/
void varcleanup(varlevel)
int varlevel;
{ extern VARIABLE *VARLINK;
  VARIABLE *varlink, *nextvar;
 
  varlink=VARLINK;
  while(varlink)
  { 
    nextvar=varlink->next;
    if(varlink->level > varlevel)
      forgetvarl(varlink->name,varlink->level);
    varlink=nextvar;
  }
}
#endif /* CIOVARS */
/*=========================  errout =========================*/
int errout()
{ char T[80];
  get_line(NULL,T,80,false);
  eruit("\007wrong!",NULL);
  return 0;
}

/* @(#)putout.c         28/04/97 18:03 */
#ifndef cio_h
#include <cio/cio.h>
#endif /* cio_h */

/* All screen output should go via the routines
   sputout(char *text), putout(), and newline()
   The sequence sprintf(OUTPUTline,arg1,...,argn); putout();
   may be obtained by the macro's sput1(arg1), sput2(arg1,arg2), ...
   defined in cio.h
*/
/*======================== putout ========================*/
void putout()
{
  if(OUTPUTline[0] != '\0') sputout(OUTPUTline);
#ifdef DEBUG
  else sputout(" warning: redundant call putout\n");
#endif
  OUTPUTline[0]='\0';
}
/*======================== sputout ========================*/
void sputout(text) char *text;
{
#ifdef MS_DOS
  PutLine(text);
#else
  fputs(text,stdout); fflush(stdout);
#endif
  if(LOGOUTPUT)fput_log(text);
}
/*======================== fput_log =======================*/
void fput_log(text) char *text;
{ int stat=0;
  char c;
  FILE *flog;

  flog=lu[14];
  if(!flog)stat= EOF;
  while(*text)
  { if(stat == EOF)
    { LOGINPUT=LOGOUTPUT=false;
      sputout("LOGFILE ERROR! no more logging\n");
      return;
    }
    c = *text++;
#ifdef MS_DOS
    if(c=='\n') stat= putc('\r',flog);
    if(stat != EOF)
#endif
    stat= putc(c,flog);
  }
  fflush(flog);
}
/*======================== newline ========================*/
void newline()
{ sputout("\n");
}
/*======================== MS_DOS hospital ==================*/
/* routines that are broken or absent */
#ifdef MS_DOS
#ifdef BORLAND
#undef get_text
#include <conio.h>

int PutLine(text) char *text;
{ int c;

  while(*text)
  { putch(c = *text++);
    if(c=='\n')putch('\r');
  }
  return 0;
}

int GetLine(text) char *text;
{ return read(0,text,LINE_LEN-1); }
#endif

#ifdef unix /* for testing DOS quirks under Unix */
int PutLine(text) char *text;
{ int c;

  while(*text)
  { putchar(c = *text++);
    if(c=='\n')putchar('\r');
  }
  fflush(stdout);
  return 0;
}

int GetLine(text) char *text;
{ return read(0,text,LINE_LEN-1); }
#endif 

#endif

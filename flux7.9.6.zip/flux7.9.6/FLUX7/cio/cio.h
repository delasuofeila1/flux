/* @(#)cio.h            23/06/00 13:14 */
/* include file for programs using the cio package  */

/* 
   One of the following should be defined:
   "unix"
   "os9"
   "MS_DOS"

   The following defines are optional:
   ANSI        for ansi prototypes, define if it works
   BUILTINMORE use built-in 'more' instead of system pager
               advantage: handles Unix, OS9 and MS_DOS files without
               stumbling over different end-of-line sequences.
               disadvantage: no directives, except 'q' for quit.
   HAVE_ISNAN  should be defined if isnan and isinf are implemented
   QUITFPERR   may be defined, if isnan and isinf are not implemented,
               if system crashes on floating point errors
               (define for Borland C, undefine for most Unices)
   WITH_CLE    define if gnu_readline and gnu_history are available.
               To compile the modified version of (gnu) history.c
               also define HAVE_STRING_H and HAVE_UNISTD_H.
   DONTHAVE_CURSES define is 'termcap' is available but 'curses' is not.
   NOVALUES    if system does not have values.h
   CIOVARS     define, except for applications where CIO variables are
               not needed.
   IGNORE_ALTIO define if ciomenu not needed, defined automatically
               for other then Unix and OS9.
   f77_UNDERSCORE_AFTER define for linkage to Fortran compilers that
               expect a _ after the module name.
               Defined automatically if "sgi" is defined.
*/

#ifndef cio_h

#ifdef __TURBOC__
#define BORLAND         /* Borland C, Turbo C */
#define MS_DOS
#endif

#ifdef _MSC_VER
#define MICROSOFT       /* Microsoft C */
#define MS_DOS
#endif

#ifdef _MINGW
#define unix
#define MINGW
#endif

#ifndef unix
#ifndef os9
#define MS_DOS
#endif
#endif

/* int4 and int4x : 4-byte integer */
#define int4  int
#define int4x unsigned int

#ifndef _TIME_
#include <time.h>
#define _TIME_
#endif

#include <setjmp.h>     /* for longjmp facility */
#include <ctype.h>
#include <stdio.h>
#include <math.h>
#include <errno.h>

#ifdef unix

#define HAVE_ISNAN

#define readln read     /* OS9-C uses readln, unix uses read */
#define EOL0 10         /* <linefeed> is end-of-line character */
#define EOL1 13         /* <return> is to be converted to EOL */
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#define gettext get_text_  /* gettext and getline may be builtin */
#define getline get_line_

#ifdef NOVALUES
#define MAXFLOAT ((float)3.40282347e38)
#define MINFLOAT ((float)1.17549435e-38)
#define MAXINT (2147483647)
#else
#include <values.h>
#endif /* NOVALUES */
#define SLASH '/'

#else /* not unix */

#ifdef os9
#define EOL0 13         /* <return> is end-of-line character */
#define EOL1 10         /* <linefeed> is to be converted to EOL */
#include <types.h>
#include <strings.h>    /* OS9-C only knows strings.h */
#define strchr index
#define strrchr rindex
#define MAXFLOAT ((float)3.40282347e38)
#define MINFLOAT ((float)1.17549435e-38)
#define MAXINT (2147483647)
#define SLASH '/'
typedef unsigned int size_t;
#endif /* os9 */

#ifdef MS_DOS
#define QUITFPERR
#define BUILTINMORE
#define CIOVARS
#define EOL0 10         /* <linefeed> is end-of-line character */
#define EOL1 13         /* <return> is to be converted to EOL */
#include <sys/types.h>
#include <string.h>
#include <stdlib.h>
#include <io.h>
#ifdef BORLAND
#include <dir.h>
#endif
#include <float.h>
#include <limits.h>
#define MAXFLOAT FLT_MAX
#define MINFLOAT FLT_MIN
#define MAXINT   INT_MAX
#define SLASH '\\'
#endif /* MS_DOS */
#endif /* unix */

#ifdef MS_DOS              /* further DOS peculiarities */
#define gettext get_text_  /* standard lib has function gettext */
#define getline get_line_
FILE *ufopen(char *filename, char *mode);
#else
#define ufopen fopen
#endif /* MS_DOS */

#define true 1
#define false 0

#define NOTHING 0x80000000L        /* default default values */
#define DNOTHING -1.0E+300
#define SNOTHING 0x8000

#define EPS 1.0e-12                /* estimated "double" accuracy */
#define twoxx32 0.4294967296e10    /* 2^32 as a "double" constant */
#define twoxx31 0.2147483648e10    /* 2^31 as a "double" constant */

#define PADDO 0x7f                /* padding character */

#define LINE_LEN 256              /* length of line buffers */

#define printexpr kalk            /* for backwards compatibility */
/*=========================  type definitions  =========================*/
typedef struct
{ char *keyword;          /* pointer to keyword string */
  int  (*function)();     /* pointer to function returning int */
  int  argument;
} COMMAND;

typedef char Varname[9];  /* variable name (string) */

typedef struct var
{ Varname name;           /* variable name */
  char type;              /* c, i, f, d    */
  char level;             /* VARLEVEL, 0=permanent */
  char msize1;            /* size in bytes of one element */
  int4 size;              /* size in bytes */
  char *valpt;            /* pointer to contents */
  struct var *next;       /* pointer to next var */
  int4 base;              /* room for variable value */
} VARIABLE;

typedef struct
{ Varname parent;         /* original name */
  int4 offset;            /* offset in units of elementary variable */
  int4 nelements;         /* number of elements */
  VARIABLE vardes;        /* room for variable descriptor */
} overlapvar;

typedef struct
{ char *vcharpt;
  int  inputpt;
  int  inputlen;
  char inputline[LINE_LEN];
  char inputeol;
  char inputeok;
  char cmdline;
  VARIABLE *varlink;
  VARIABLE *forindex;
  int4  repcount;
} CONTEXT;

typedef struct
{ int4 nr;
  char *message;
} CIO_ERR;

#define maxcontexts 16

#define Ncontrolstack 1024

#ifndef SEEK_SET
#define SEEK_SET 0
#define SEEK_CUR 1
#define SEEK_END 2
#endif

typedef struct
{ int4 seq;               /* sequence number */
  int4 extranum;          /* extra number to identify set of spectra */
  int4 length;            /* length of spectrum (in channels) */
  int4 seconds;           /* duration of measurement in seconds */
  int4 day;
  int4 month;
  int4 year;              /* day, month, year of data acquisition */
  int4 rtime;             /* real time clock */
  int4 ltime1;            /* live time clock */
  int4 ltime2;            /* second live time clock */
  int4 ltime3;            /* third live time clock */
  int4 offset;            /* offset subtracted of each channel */
  int4 factor;            /* multiplier applied before packing */
  /* the above are set by the program calling PUTSP,
     the next items, i.e. nbits .. lastnz, are determined by PUTSP */
  int4 nbits;             /* number of bits of each channel */
  int4 nrecords;          /* number of 256-byte records written */
  int4 lastnz;            /* last channel not containing zero */
  float rlab[16];         /* 16 single float numbers R-var's [0..15] */
  char notes[128];        /* descriptive text */
} LABELRECORD;

#define MAXLU 16
#define CLOSED    0
#define OPEN_READ 1
#define OPEN_RW   2
#define ASCIIFILE 16
#define GETSPFILE 32
#define PEGETSPFILE 64

#define GRINTBUFLEN 1024

#define HANDSHAKE '@'
/* handshake character, used by GUI */

typedef struct sp_type
{
   Varname name;
   LABELRECORD lab;
   int4 length;
   char sptype;
   struct sp_type *next;
   struct sp_type *previous;
} spectrum;

/* specifiers for termflag and skipflag in getargtext and readchar  */
/*  termflag = termEOK implies also termEOL,                        */
/*  but termEOL does not automatically imply termEOK.               */
/*  Specifying termEOL allows semicolons to be included in the text */
#define termEOL           1  /* get text terminated by end of line  */
#define termEOK           2  /* get text term. by EOL or semicolon  */
#define termspace         4  /*  "   "   term. by EOL, EOK or space */
#define termcomma         8  /*  "   "   term. by EOL, EOK or comma */
#define termA termspace|termcomma   /* any of the above */
#define substalias       32  /* allow alias substitution */
#define skipblank        64  /* skip leading spaces */
#define skipEOL         128  /* read new line when at EOL */
#define skipEOK         256  /* skip to next command, on current line */
#define skipA skipblank|skipEOL /* skip spaces,  new line if at EOL */
#define skipC skipA|skipEOK  /* skip to next command */
#define resetLN         512  /* "rewind" current line */
#define resetCMD       1024  /* "rewind" current command */
#define dontread       2048  /* process "skipflag" only */
#define termquote      4096  /* for internal use only   */
#define rawread        8192  /* ignore special meaning of symbols */

/* status bits returned by various functions */
#define errstat    0x80000000L      /* set if error status */
#define notinteger 0x00000001L      /* number is non-integer */
#define isciovar   0x00000001L      /* text is a cio variable */
#define nonumber   0x00000002L      /* no number decoded   */
#define EOString   0x00000004L      /* end of string encountered */
#define delimiterr 0x00000008L      /* delimiter ) or ] encountered */
#define defstat    0x00000010L      /* default value used */
#define numerr     0x00000020L     /* numerical error */
#define syntaxerr  0x00000040L
#define varnamerr  0x00000080L
#define operanderr 0x00000100L      /* bad operand */
#define truncaterr 0x00000200L      /* text truncated */
#define rangerr    0x00000400L      /* outside permissible range */
#define filerr     0x00000800L      /* file error */
#define conflict   0x00001000L      /* name or type conflict */
#define Qstat      0x00002000L      /* "q" when number was asked */
#define EOFstat    0x00004000L      /* end of file encountered */
#define nosubscrpt 0x00008000L      /* subscript missing */
#define undefined  0x00010000L      /* undefined variable */
#define illterm    0x00020000L  /* ill. terminator, other then ) or ] */
#define readerr    0x00040000L  /* read error */
#define writerr    0x00080000L  /* write error */
#define formaterr  0x00100000L  /* error in file format */
#define notfoundr  0x00200000L  /* spectrum, file, or ? not found */

/* aliases for 'sprintf(OUTPUTline .... printout()' */
#define s_OUT(_p0)                 sprintf(OUTPUTline,_p0
#define sput1(_p0)                 sputout(_p0)
#define sput2(_p0,_p1)             s_OUT(_p0),_p1), putout()
#define sput3(_p0,_p1,_p2)         s_OUT(_p0),_p1,_p2), putout()
#define sput4(_p0,_p1,_p2,_p3)     s_OUT(_p0),_p1,_p2,_p3), putout()
#define sput5(_p0,_p1,_p2,_p3,_p4) s_OUT(_p0),_p1,_p2,_p3,_p4), putout()
#define sput6(_p0,_p1,_p2,_p3,_p4,_p5)                          s_OUT(_p0),_p1,_p2,_p3,_p4,_p5), putout()
#define sput7(_p0,_p1,_p2,_p3,_p4,_p5,_p6)                      s_OUT(_p0),_p1,_p2,_p3,_p4,_p5,_p6), putout()
#define sput8(_p0,_p1,_p2,_p3,_p4,_p5,_p6,_p7)                  s_OUT(_p0),_p1,_p2,_p3,_p4,_p5,_p6,_p7), putout()
#define sput9(_p0,_p1,_p2,_p3,_p4,_p5,_p6,_p7,_p8)              s_OUT(_p0),_p1,_p2,_p3,_p4,_p5,_p6,_p7,_p8), putout()
#define sput10(_p0,_p1,_p2,_p3,_p4,_p5,_p6,_p7,_p8,_p9)         s_OUT(_p0),_p1,_p2,_p3,_p4,_p5,_p6,_p7,_p8,_p9), putout()
#define sput11(_p0,_p1,_p2,_p3,_p4,_p5,_p6,_p7,_p8,_p9,_pA)     s_OUT(_p0),_p1,_p2,_p3,_p4,_p5,_p6,_p7,_p8,_p9,_pA), putout()
#define sput12(_p0,_p1,_p2,_p3,_p4,_p5,_p6,_p7,_p8,_p9,_pA,_pB) s_OUT(_p0),_p1,_p2,_p3,_p4,_p5,_p6,_p7,_p8,_p9,_pA,_pB), putout()

/*========================= GLOBAL VARIABLES =========================*/

extern void (*FIRST_PROC)();
extern void (*CIO_RECOVER)();

extern char *PROGRAMNAME; /* command used to start current program */
extern char *what_cio;    /* cio version string */

extern VARIABLE *VARLINK;
extern int VARLEVEL;

extern VARIABLE *FORINDEX;
extern int4 REPCOUNT;

extern jmp_buf environment;

extern char *INPUTchpt,INPUTline[LINE_LEN],INPUTEOL,INPUTEOK,CMDLINE,
            ITRACE,ISTEP,INTERACTIVE[3];
extern int  INPUTlen, INPUTpt;

extern char OUTPUTline[LINE_LEN];

extern int  LINES_ON_SCREEN;
extern char INTERRUPT;

#ifdef WITH_CLE
extern char HISTORYline[LINE_LEN];
extern int HISTORYlinelen;
extern int HISTORYdefaultentry;
#endif

extern CONTEXT contexts[maxcontexts];
extern int ncontext,ercontext,ercontrolpt;

extern char controlstack[Ncontrolstack];
extern int controlpointer;
extern char breakflag;

extern FILE *lu[MAXLU];
extern char lumode[MAXLU];
extern char fname[MAXLU][80];

extern char  LOGINPUT, LOGOUTPUT;

extern FILE *toGUI;
extern int ORIGINAL_FD[2];
extern int CURRENT_FD[2];
extern int menu_open;

extern spectrum *sp1;
extern char host[20];
extern char y_name[9];
extern int4 ifrom,ito;

/* = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */
#ifdef sgi
#define f77_UNDERSCORE_AFTER yes
#endif

#ifdef f77_UNDERSCORE_AFTER
#define bckplf bckplf_
#define beggep beggep_
#define begpic begpic_
#define ciobeg ciobeg_
#define cllsq cllsq_
#define crlf crlf_
#define cubgcv cubgcv_
#define cursor cursor_
#define ddat ddat_
#define dparg dparg_
#define endgep endgep_
#define endpic endpic_
#define eruit_ eruit__
#define fexpandfn fexpandfn_
#define flushb flushb_
#define fonti fonti_
#define getmass getmass_
#define getnum_ getnum__
#define getvar getvar_
#define intarg intarg_
#define intchar intchar_
#define iselect iselect_
#define iselect1 iselect1_
#define isotop isotop_
#define itxtostr_ itxtostr__
#define linearg linearg_
#define llsq llsq_
#define magneet magneet_
#define marker marker_
#define mscan mscan_
#define ntermval ntermval_
#define out_ out__
#define plco plco_
#define plot plot_
#define pltext pltext_
#define pltv pltv_
#define putinsp putinsp_
#define realarg realarg_
#define relkin relkin_
#define setterm setterm_
#define skipper skipper_
#define spline_smo spline_smo_
#define symbol symbol_
#define tvtext tvtext_
#define txtarg txtarg_
#define upcase upcase_
#define wrflush wrflush_
#define writi writi_
#define writr writr_
#define writt writt_
#define xgetsp xgetsp_
#define zzzbeg zzzbeg_
#define zzzcls zzzcls_
#define zzzend zzzend_
#define zzzflsh zzzflsh_
#define zzzfnt zzzfnt_
#define zzzgin zzzgin_
#define zzznwp zzznwp_
#define zzzopn zzzopn_
#define zzzpln zzzpln_
#define zzzsym zzzsym_
#define zzztkginput zzztkginput_
#endif

/* = = = = = = = = function type specification = = = = = = = = = */

FILE *searchfile();

VARIABLE *declaration();
VARIABLE *existvar();
VARIABLE *instalv();
VARIABLE *instalvv();
VARIABLE *retrieve();
VARIABLE *testoverlap();
VARIABLE *testvar();
VARIABLE *vardefc();
VARIABLE *vardefd();
VARIABLE *vardeff();
VARIABLE *vardefi();

Varname *vargetv();

char **set_Dirlist();
char *expandfn();
char *getbase();
char *getvarpointer();
char* look_ahead_inp();
char *luname();
char *mprompt();
char *printerr();
char *prodir();
char *sprompt();
char *testrange();
char *ugets();
char *vargetc();

double *doubledef();
double *vargetd();
double DAT();
double ddat();
double dxxi();
double interpol();
double minmax();
double spsum();
double spzero();

float *fglobvar();
float *vargetf();
float floatpe();

int altio();
int altiox();
int ap_close();
int ap_cur();
int ap_defsp();
int ap_dir();
int ap_display();
int ap_displayv();
int ap_dix();
int ap_dixgraph();
int ap_dlu();
int ap_edit();
int ap_get();
int ap_gettime();
int ap_graph();
int ap_grint();
int ap_import();
int ap_init();
int ap_lablist();
int ap_map();
int ap_mapopt();
int ap_more();
int ap_move();
int ap_open();
int ap_pause();
int ap_plot();
int ap_prlab();
int ap_put();
int ap_redraw();
int ap_rewind();
int ap_shell();
int ap_sleep();
int ap_spl();
int ap_stop();
int ap_stopgrint();
int ap_system();
int ap_undef();
int ap_xex();
int aphelp();
int asklu();
int bekijkm();
int cdo();
int cenddo();
int cendif();
int cendrep();
int cendwh();
int check_term();
int cif();
int cio_exit();
int cio_stat();
int cio_stop();
int ciomenu();
int cllsq();
int cls();
int cputout();
int crepeat();
int cscan();
int cselect();
int cselect1();
int cselect2();
int ctrinp();
int ctrl_done();
int ctroutp();
int cwhile();
int dips();
int duo();
int enter_standout();
int erin();
int erpol();
int errout();
int exit_standout();
int flushdefs();
int fneedlines();
int fprinttext();
int fputch();
int get_more_char();
int get_single_char();
int getcommandline();
int gong();
int history();
int iflush_grint();
int initf();
int ire_grint();
int iselect();
int iselect1();
int istartgrint();
int itxtostr_();
int iwr_grint();
int kalk();
int keepm();
int lab_getset();
int linesonscreen();
int listVAR();
int lookc();
int mcomp();
int mojump();
int mscan();
int needlines();
int onlinehelp();
int overlap();
int peakprint();
int printexpr();
int printtext();
int qprdefs();
int readaline();
int read_asci();
int setlog();
int setvar();
int setvarlst();
int shiftsp();
int slice();
int spcopy();
int spline_smo();
int sprinttext();
int stept();
int trace();
int trio();
int undef_sp();
int uno();
int varsize();
int wipeout();
int wr_gui();
int xctload();
int xp();

int4  getcommand();
int4  getint();
int4  getixpr();
int4  getline();
int4  getrawline();
int4  getreal();
int4  gettext();
int4  getvar();
int4 *vargeti();
int4 cgetint();
int4 cgetreal();
int4 cgetsp();
int4 cputsp();
int4 ctr();
int4 evalvar();
int4 evalxp_();
int4 fdflush();
int4 filelen();
int4 filetovar();
int4 getaline();
int4 getargtext();
int4 getcond();
int4 getsubfile();
int4 getusertext();
int4 globalvar();
int4 intchar_();
int4 intget_ ();
int4 isinteractive();
int4 keepvar();
int4 keepvarl();
int4 lu_close();
int4 lu_init();
int4 lu_open();
int4 lu_rewind();
int4 n_int();
int4 numget_ ();
int4 readchar();
int4 resetcmd();
int4 resetln();
int4 sighand();
int4 skipper();
int4 substenv();
int4 test_table();
int4 xgetcommand();
int4 xgetint();
int4 xgetixpr();
int4 xgetline();
int4 xgetrawline();
int4 xgetreal();
int4 xgetsp();
int4 xgettext();
int4 xgetvar();
int4 xkeepvar();
int4 yesno();

spectrum *def_sp();
spectrum *get_sp();

void arstore();
void checktype();
void checkvar();
void crlf();
void cwritd();
void cwritg();
void destroygrint();
void differentiate();
void dinamex();
void doublearray();
void dparg();
void dumpcontext();
void eruit();
void eruit_();
void fexpandfn();
void flarstore();
void floatarray();
void forgetvar();
void forgetvarl();
void fput_log();
void getdistext();
void getnum_();
void get_the_time();
void gontran();
void grint_datum();
void grint_label();
void grint_line();
void grint_ndata();
void grint_poly();
void grint_scale();
void ieruit();
void init_graph();
void init_picture();
void intarg();
void intarray();
void intarstore();
void linearg();
void listcom();
void listcom_();
void listsubfile();
void listvar();
void mv_bytes();
void newline();
void out_();
void plotlab();
void poesje();
void popc();
void popcontext();
void prdefd();
void prdefd_table();
void prdefi();
void prdefi_table();
void prdefs();
void prdefs_table();
void prdefsd_table();
void prdefsi_table();
void printlabel();
void printtime();
void prtime();
void pushc();
void pushcontext();
void putinsp();
void putout();
void re_grint();
void realarg();
void reset();
void rstcontext();
void showmap();
void sigint();
void sigquit();
void spinc();
void spmult();
void sptrunc();
void sputout();
void startgrint();
void storeDAT();
void txtarg();
void upcase();
void valtovar();
void varalias();
void varcleanup();
void varsave();
void varstore();
void waitgrint();
void wr_cur();
void wr_distext();
void wr_grint();
void wr_line();
void wrclean();
void wrerdata();
void wrflush();
void wrget();
void wrgrint();
void writcheck();
void writi();
void writr();
void writt();
void wrsdata();
void wrvdata();
void wrxdata();
void xprinterr();

#ifdef MS_DOS
int4  getshort();
int4 cgetshort();
int4 xgetshort();
int PutLine();
int GetLine();
#endif

#ifdef os9
double atan2();
char *getcwd();
char *getenv();
#endif

#ifdef ANSI
#include <cio/proto.h>
#endif /* ANSI */

#define cio_h 1
#endif /* cio_h */

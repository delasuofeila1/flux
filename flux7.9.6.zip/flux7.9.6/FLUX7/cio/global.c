/* @(#)global.c         04/04/01 11:42 */
char *what_cio= "@(#)cio: version 4.67 June 17 1997";
/* = = = = = = = = = = = = global.c  = =  = = = = = = = = = = = = */
/*============ definition of global variables  ===================*/
#ifndef cio_h
#include <cio/cio.h>
#endif /* cio_h */

/* GLOBAL VARIABLES */

VARIABLE *VARLINK;
int   VARLEVEL=1;

void (*FIRST_PROC)() = NULL; /* hook for 'first time through' proc. */
void (*CIO_RECOVER)() = NULL; /* alternative for long_jmp */

jmp_buf environment;

char *INPUTchpt=NULL,   /* pointer used when input is char variable */
      INPUTline[LINE_LEN], /* current input line buffer */
      INPUTEOL=false,
      INPUTEOK=false,
      CMDLINE,          /* flag, true when processing command line */
      ITRACE=false,     /* flag, true when TRACE enabled */
      ISTEP=false,      /* flag, true when STEP enabled */
      INTERACTIVE[3]={true, true, true}
        ; /* flag, true when stdin, stdout, stderr is interactive */
char  INTERRUPT=false;  /* set when an interrupt signal is received */

int   INPUTlen=0,       /* length of current input line */
      INPUTpt=0;        /* INPUTline[INPUTpt] is current character */

char  OUTPUTline[LINE_LEN];

int   LINES_ON_SCREEN=24; /* overruled by environmental variable NLINES
                             and by termcap info */


CONTEXT contexts[maxcontexts]; /* save area for context switches */
int   ncontext=0,
      ercontext=0;      /* used by CONTINUE command */

int4  REPCOUNT;         /* used by REPEAT and FOR commands */
VARIABLE *FORINDEX;     /* used by FOR */

char  controlstack[Ncontrolstack];
int   controlpointer=Ncontrolstack-1,
      ercontrolpt;

char  breakflag=false;

FILE *lu[MAXLU];
char  lumode[MAXLU];
char  fname[MAXLU][80];

char  LOGINPUT=false,   /* true if input logging is requested */
      LOGOUTPUT=false;  /* true if output logging is requested */

FILE *toGUI=NULL;

int ORIGINAL_FD[2]= { -1, -1};
int CURRENT_FD[2]= { -1, -1};
int menu_open= false;

spectrum *sp1 = NULL;

char *PROGRAMNAME;

Varname y_name;
int4 ifrom=0, ito=99;
/* = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */

/* @(#)getargs.c        15/04/12 13:07 */
#ifndef cio_h
#include <cio/cio.h>
#endif /* cio_h */

int HISTORY_default_substitute = true;
char HISTORYline[LINE_LEN];
int HISTORYlinelen, HISTORYdefaultentry;

#ifdef ANSI
int add_to_HISTORYline(char *text);
int add_default_to_HISTORYline(int token, char *T);
int4 ask_user(char *prompt, char *auxtext,int4 auxlen,int4 auxdefault);
#endif

#ifdef WITH_CLE

#include <readline/readline.h>
#include <readline/history.h>

#else

/* if 'WITH_CLE' is not defined, the functions 'add_history' and
   'write_history' of the GNU readline library are not used,
    but built-in versions instead. To name clashes during the
    linking phase, give them different names:
*/
#define add_history my_add_history
#define write_history my_write_history
#ifdef ANSI
int my_add_history(char line[]);
int my_write_history(char *pfile);
#else
int my_add_history();
int my_write_history();
#endif

#define HISlines 64
#define HISchars 1024
static char HISTORY[HISchars];
static int HISlinept[HISlines];
static int HISlen[HISlines];
static int HISlineno[HISlines];
static int HISline= -1; /* index of last written history line */
static int HISnr=0;

#endif


/*========================== add_to_HISTORYline ===============*/
int add_to_HISTORYline(text)
char *text;
{ int len;
  char cx='\0';

  len=strlen(text);
  if (len) 
  { if (len+HISTORYlinelen >= LINE_LEN)
    { 
      add_history(HISTORYline);
      HISTORYlinelen = 0;
      *HISTORYline= '\0'; /* added 2/6/97 PJMS */
    }
/* insert a space after previous text, if necessary */
    if(HISTORYlinelen > 0) cx=HISTORYline[HISTORYlinelen-1];
    if((cx)&&(cx!=' ')&&(cx!=','))
    if((*text!=' ')&&(*text!=','))
    { strcat(HISTORYline," ");
      HISTORYlinelen++;
    }

    strcat(HISTORYline,text);
    HISTORYlinelen += len;
  }
  return(0);
}
/*========================== add_default_to_HISTORYline ===========*/
int add_default_to_HISTORYline(token,T)
int token;
char *T;
/* if token == '\n' write newline in history file, else add ","    */
{ 
  if(HISTORY_default_substitute) add_to_HISTORYline(T);

  if(token == '\n')
  {
    add_to_HISTORYline("\n");
    add_history(HISTORYline);
    HISTORYline[0] = '\0';
    HISTORYlinelen = 0;
  }
  else
  { if((HISTORYlinelen > 0)&&(HISTORYline[HISTORYlinelen-1] != ',')
    &&((!HISTORY_default_substitute)||(*T == '\0')))
      add_to_HISTORYline(",,");
    else
      add_to_HISTORYline(",");
  }
  return 0;
}
/*==========================  getint  ========================*/
int4 xgetint(prompt,I,cdefault)
char *prompt;
int4 *I,cdefault;
{ int4 stat;
  stat=getint(prompt,I,cdefault);
  if(stat&errstat)xprinterr(stat);
  return(stat);
}
/*==========================  xgetixpr  =======================*/
int4 xgetixpr(prompt,I,cdefault)
char *prompt;
int4 *I, cdefault;
{ int4 stat;
  stat=getixpr(prompt,I,cdefault);
  if(stat&errstat)xprinterr(stat);
  return(stat);
}
/*==========================  xgetreal  =======================*/
int4 xgetreal(prompt,R,cdefault)
char *prompt;
double *R;
int4 cdefault;
{ int4 stat;
  stat=getreal(prompt,R,cdefault);
  if(stat&errstat)xprinterr(stat);
  return(stat);
}
/*========================== xgetcommand  =====================*/
int4 xgetcommand(prompt,T,len,cdefault)
char *prompt, *T;
int4 len,cdefault;
{ int4 stat;
  stat=getcommand(prompt,T,len,cdefault);
  if(stat&errstat)xprinterr(stat);
  return(stat);
}
/*==========================  xget_text  =======================*/
int4 xget_text(prompt,T,len,cdefault)
char *prompt, *T;
int4 len,cdefault;
{ int4 stat;
  stat=get_text(prompt,T,len,cdefault);
  if(stat&errstat)xprinterr(stat);
  return(stat);
}
/*==========================  xget_line  =======================*/
int4 xget_line(prompt,T,len,cdefault)
char *prompt, *T;
int4 len,cdefault;
{ int4 stat;
  stat=get_line(prompt,T,len,cdefault);
  if(stat&errstat)xprinterr(stat);
  return(stat);
}
/*==========================  xgetrawline ======================*/
int4 xgetrawline(prompt,T,len,cdefault)
char *prompt, *T;
int4 len,cdefault;
{ int4 stat;
  stat=getrawline(prompt,T,len,cdefault);
  if(stat&errstat)xprinterr(stat);
  return(stat);
}
#ifdef CIOVARS
/*========================== xgetvar  ========================*/
#ifndef cio_h
#include <cio/cio.h>
#endif /* cio_h */

int4 xgetvar(prompt,V,name,cdefault)
char *prompt;
VARIABLE **V;
Varname name;
int4 cdefault;
{ int4 stat;
  stat=getvar(prompt,V,name,cdefault);
  if(stat&errstat)xprinterr(stat);
  return(stat);
}
/*==========================  getvar  ========================*/
#ifndef cio_h
#include <cio/cio.h>
#endif /* cio_h */

int4 getvar(prompt,V,name,cdefault)
char *prompt;
VARIABLE **V;
Varname name;
int4 cdefault;
/* get a variable name from the input stream, return pointer *V */
/* when input is empty, leave *V unchanged if cdefault is true */
/* and set *V to NULL pointer if cdefault is false    */
/* When input is a variable of type 'v' (without subscript), */
/* ier is set to (errstat|nosubscrpt), *V= NULL, but 'name' is valid */
{ char T[LINE_LEN];
  int4 len=LINE_LEN-1,ipt,stat,term=0;
  strncpy(T,name,9); /* put default value in T */
  stat=get_text(prompt,T,len,cdefault);
  strncpy(name,T,8);
  if ( (stat==0) || ( cdefault && (stat==defstat)))
  { ipt=0;
    stat=evalvar(T,&len,&ipt,V,name,&term);
    if((stat&undefined)&&(name[0]=='\0'))strncpy(name,T,8);
    if(term)stat|=(errstat|syntaxerr); /* trailing garbage */
    if(stat&errstat) *V=NULL;
  }
  else *V=NULL;
  return(stat);
}
#endif
/*==========================  getcommand  =====================*/
#ifndef cio_h
#include <cio/cio.h>
#endif /* cio_h */

int4 getcommand(prompt,T,len,cdefault)
char *prompt, *T;
int4 len,cdefault;
{ int4 stat;
  stat=getargtext(prompt,T,len,cdefault,termA|substalias,skipC);
  return(stat);
}

#ifdef MS_DOS
/*========================== xgetshort  =======================*/
int4 xgetshort(prompt,I,cdefault)
char *prompt;
short int *I;
int4 cdefault;
{ int4 stat;
  stat=getshort(prompt,I,cdefault);
  if(stat&errstat)xprinterr(stat);
  return(stat);
}
/*==========================  getshort  =======================*/
#ifndef cio_h
#include <cio/cio.h>
#endif /* cio_h */

int4 getshort(prompt,I,cdefault)
char *prompt;
short int *I;
int4 cdefault;
/* get a short integer argument from the input stream, answer in *I */
/* when input is empty, leave *I unchanged if cdefault is true */
/* and set *I to large negative number if cdefault is false    */
{
  int4 stat,LongI;

  LongI= (long) (*I);
  stat= getint(prompt,&LongI,cdefault);
  *I=(short int)LongI;

  if( (stat&notinteger) 
    || (LongI > 0x7fff) || (LongI < -(long)0x7fff) )
  {
    stat|=(errstat|numerr);
  }
  else
  if((! cdefault)&& stat==defstat) *I=SNOTHING;

  return(stat);
}
#endif /* MS_DOS */

/*==========================  getint  ========================*/
#ifndef cio_h
#include <cio/cio.h>
#endif /* cio_h */

int4 getint(prompt,I,cdefault)
char *prompt;
int4 *I,cdefault;
/* get an integer argument from the input stream, answer in *I */
/* when input is empty, leave *I unchanged if cdefault is true */
/* and set *I to large negative number if cdefault is false    */
{ char T[80];
  int4 len,ipt,ianswer,term,stat;
  double fanswer;

  len=80;
  sprintf(T,"%d",*I); /* put default value in string T */
  stat=get_text(prompt,T,len,cdefault);
  if (stat==0)
  { ipt=0;
    stat=evalxp_(T,&len,&ipt,&ianswer,&fanswer,&term);
    *I=ianswer;
    if((stat&notinteger) && (fabs(fanswer) > twoxx31))
     stat|=(errstat|numerr);
  } else if((! cdefault)&& stat==defstat) *I=NOTHING;

  return(stat);
}

/*==========================  getixpr  =======================*/
#ifndef cio_h
#include <cio/cio.h>
#endif /* cio_h */

int4 getixpr(prompt,I,cdefault)
char *prompt;
int4 *I;
int4 cdefault;
/* get an integer expression from the inputstream, answer in *I */
/* when input is empty, leave *I unchanged if cdefault is true */
/* and set *I to large negative number if cdefault is false.   */
/* Difference with getint: the expression may contain spaces.  */
{ char T[80];
  int4 len,ipt,ianswer,term,stat;
  double fanswer;
  len=80;
  sprintf(T,"%d",*I); /* put default value in string T */
  stat=get_line(prompt,T,len,cdefault);
  if (stat==0)
  { ipt=0;
    stat=evalxp_(T,&len,&ipt,&ianswer,&fanswer,&term);
    *I=ianswer;
    if((stat&notinteger) && (fabs(fanswer) > twoxx31))
     stat|=(errstat|numerr);
  } else if((! cdefault)&& stat==defstat) *I=NOTHING;

  return(stat);
}
/*==========================  get_line  =======================*/
#ifndef cio_h
#include <cio/cio.h>
#endif /* cio_h */

int4 get_line(prompt,T,len,cdefault)
char *prompt, *T;
int4 len,cdefault;
{ int4 stat;

  stat = getargtext(prompt,T,len,cdefault,termEOL|termEOK,skipA);

/* if default value is taken and HISTORYdefaultentry == TRUE
   put the default value in the history line */

  if(stat==defstat && HISTORYdefaultentry)
      add_default_to_HISTORYline('\n',T);

  return(stat);
}
/*==========================  getrawline  =======================*/
#ifndef cio_h
#include <cio/cio.h>
#endif /* cio_h */

int4 getrawline(prompt,T,len,cdefault)
char *prompt, *T;
int4 len,cdefault;
{ int4 stat;
  stat=getargtext(prompt,T,len,cdefault,rawread|termEOL,skipEOL);

/* if default value is taken and HISTORYdefaultentry == TRUE
   put the default value in the history line */

  if(stat==defstat && HISTORYdefaultentry)
      add_default_to_HISTORYline('\n',T);

  return(stat);
}
/*==========================  getreal  =======================*/
#ifndef cio_h
#include <cio/cio.h>
#endif /* cio_h */

int4 getreal(prompt,R,cdefault)
char *prompt;
double *R;
int4 cdefault;
/* get a double precision argument from the inputstream, answer in *R */
/* when input is empty, leave *R unchanged if cdefault is true */
/* and set *R to large negative number if cdefault is false    */
{ char T[80];
  int4 len,ipt,ianswer,term,stat;
  double fanswer;
  len=80;
  sprintf(T,"%.9g",*R); /* put default value in T */
  stat=get_text(prompt,T,len,cdefault);
  if (stat==0)
  { ipt=0;
    stat=evalxp_(T,&len,&ipt,&ianswer,&fanswer,&term);
    *R=fanswer;
    if(stat==notinteger) stat=0;
  } else {if((! cdefault) && stat == defstat) *R = DNOTHING;}
  return(stat);
}
/*==========================  get_text  =======================*/
#ifndef cio_h
#include <cio/cio.h>
#endif /* cio_h */

int4 get_text(prompt,T,len,cdefault)
char *prompt, *T;
int4 len,cdefault;
{ int4 stat;
  stat = getargtext(prompt,T,len,cdefault,termA,skipA);

/* if default value is taken and HISTORYdefaultentry == TRUE
   put the default value in the history line */

  if(stat==defstat && HISTORYdefaultentry)
      add_default_to_HISTORYline(',',T);

  return(stat);
}
/*==========================  resetcmd  =======================*/
/* rewind current command */
int4 resetcmd() { return(readchar("",resetCMD|dontread)); }
/*==========================  resetln  =======================*/
/* rewind current line */
int4 resetln() { return(readchar("",resetLN|dontread)); }
/*==========================  skipper  =======================*/
/* skip to next command on current line */
int4 skipper() { return(readchar("",skipEOK|dontread)); }
/*===========================  yesno  ========================*/
int4 yesno(text,qdefault) char *text; int qdefault;
/* type 'Yes/No', ask response, return 0 if NO,
   1 if YES, qdefault otherwise */
#define YES 1
#define NO 0
{ int option,len;
  char argum[40];
  len=strlen(text); if (len > 30) len=30;
  strncpy (argum,text,len);
  strcpy (&argum[len]," Yes/No:");
  get_text(argum,argum,4,0);
  argum[3]='\0';
  option=mscan(argum,"No/Yes")-1;
  if(option < 0)option= (qdefault)? YES : NO;
  return(int4) option;
}
/* ===================== look_ahead_inp =========================== */
char* look_ahead_inp()
{
/* return a pointer to the next item on the current input line.
   return a NULL pointer if EOK or EOL encountered (skipping blanks).
   Does not affect the input pointer INPUTpt!
*/
  int  saveINPUTpt= INPUTpt;
  char saveINPUTEOL=INPUTEOL;
  char saveINPUTEOK=INPUTEOK;
  char *nextarg;

  readchar(NULL,dontread|skipblank);
  nextarg= (INPUTEOK || INPUTEOL)? NULL : &INPUTline[INPUTpt];

  INPUTpt= saveINPUTpt;
  INPUTEOL=saveINPUTEOL;
  INPUTEOK=saveINPUTEOK;

  return(nextarg);
}

/*========================  getargtext  ======================*/

int4 getargtext(prompt,T,len,cdefault,termflag,skipflag)
char *prompt, *T;
int4 len,cdefault,termflag,skipflag;
/* get a text argument from the inputstream, return it in T */
/* prompt is prompt string */
/* len is maximum length of argument */
/* cdefault specifies what to do when the argument is empty */
/*          if true: leave T unchanged */
/*          if false: fill T with '\0' */
/* termflag specifies what conditions terminate the argument */
/* skipflag specifies the actions before extracting the argument */
/* see cio.h for possible values */
{ int4 i,j,c,istat,readchar();
  char *newptr;
  Varname vname;
  char isvar, askuser, raw;
#ifdef CIOVARS
  extern int VARLEVEL;
#endif
  VARIABLE *varptr;

  do
  { newptr=NULL;
    isvar = false;
    askuser = false;
    raw = true;
    if((prompt == NULL) || (*prompt == '\0'))
      skipflag&= ~skipEOL; /* ~ is complement! */
    c=readchar(prompt,skipflag|termflag);
    if ( !breakflag && !(rawread & (skipflag|termflag)))
    {
      /* test for special first characters, #, $, ', ? ,& */
      while (c=='#')
      { INPUTEOL = true; c=readchar(prompt,skipflag|termflag);
      }
      if(c=='\'')
      { termflag |= termquote; /* ignore terminators other than EOL */
        c=readchar(prompt,termflag);
      }
      else raw = false;
      if(c=='&')
      { return(errstat|EOFstat);
      }
      isvar=  ((!raw)&&(c=='$'));
      askuser=((!raw)&&(c=='?'));
    }
    if(askuser)
    {
      istat = getusertext(T,len,cdefault);
    }
    else
    {
      i=0;
      while(c>0)
      { if ((termflag & termquote) && (c=='\''))
        { termflag &= ~termquote;
        } else { if(i<len)T[i]=c; i++;}
        c=readchar(prompt,termflag);
      } ; j=i;
      if(j || !cdefault) while (i<len) T[i++]='\0';
      istat=c;
      if(istat>=0)
      { if(j==0)istat=defstat;
        if(j>len)istat=truncaterr;
      }

      if(istat==(errstat|EOFstat))
      { if(INPUTchpt)
        {
          istat=cio_exit(1);
          if(istat >= 0) newptr=(char *)1;
        }
        else
        {
          if(! INTERACTIVE[0]) cio_stop();
#ifndef IGNORE_ALTIO
          if(menu_open)
          { sleep(1);
            altiox(NULL,NULL);
          }
#endif /* ndef IGNORE_ALTIO */
          return(istat);
        }
      } else if (!raw)
      { if (termflag & substalias)
        {
          if(isvar) /* argument starting with $ */
          { i=1;
            if(evalvar(T,&j,&i,&varptr,vname,&c) & errstat)varptr=NULL;
          }
#ifdef CIOVARS
          else varptr = existvar(T,0,VARLEVEL);
          if(varptr)
          { if(varptr->type == 'c' && c != '[')newptr = varptr->valpt;
            else
            istat = isciovar;
          }
          if(newptr)poesje(newptr);
#else
	  else varptr=NULL;
#endif
        }
      }
    }
  } while(newptr);
  if( (istat == 0) && (! raw) ) istat = substenv(T,len);
  sput2("%s\n",T);
  return(istat);
}

int4 getusertext(T,len,cdefault)
char *T;
int4 len,cdefault;
{
  char prompt[80];

  /* read prompt from current input stream */
  getargtext(NULL,prompt,80,0,termA,skipA);
  return(ask_user(prompt,T,len,cdefault));
}

int4 ask_user(prompt, auxtext,auxlen,auxdefault)
char *prompt;
char *auxtext;
int4 auxlen;
int4 auxdefault;
{
  int4 auxstat;
  char c='a';

  pushcontext(); /* push context for askuser */
  pushc(&c,1);  /* also put a marker in the control stack */
  INPUTchpt=NULL; /* reset input to stdin */
  INPUTlen=0; /* force getting a new line */
  auxstat = getargtext(prompt,auxtext,auxlen,auxdefault,termEOK,skipA);
  popcontext();
  popc(&c,1);
  return(auxstat);
}
/*========================== readchar  =======================*/
int4 readchar(prompt,flag)
char *prompt;
int4 flag;
/* used by getargtext, and also by skipper, resetcmd, resetln */
{
  register int c;

/* first process resetLN, resetCMD and skipEOK flags */
  if(flag&resetLN) {INPUTpt=0; INPUTEOL=false; INPUTEOK=false;}
  if(flag&resetCMD)
  { while(INPUTpt>0) if(INPUTline[--INPUTpt]==';') {++INPUTpt; break;}
    INPUTEOL=false; INPUTEOK=false;
  }
  if(flag & skipEOK)      /* skip to EOL, EOK */
  {

    if(HISTORYlinelen>0) /* save previous command to historylist */
    {
      add_history(HISTORYline);
      HISTORYline[0] = '\0';
      HISTORYlinelen = 0;
    }
  
    while( ! (INPUTEOL || INPUTEOK || CMDLINE) )
      c=(char)readchar("",(termEOL | termEOK) );
    if(INPUTEOK){ INPUTpt++; INPUTEOK=false; }
  }
/* skip blanks if flag skipblank is up */
  if(flag & skipblank)
  while(INPUTpt<INPUTlen && INPUTline[INPUTpt]==' ')INPUTpt++;
/* pick up the current character */
  c=(INPUTpt<INPUTlen)? INPUTline[INPUTpt]: 0;
/* test for end of line: c == 0, return, or linefeed */
  INPUTEOL=(INPUTEOL || INPUTpt>=INPUTlen || c==0 || c==0x0d || c==0x0a);
  INPUTEOK=(INPUTEOK || (INPUTEOL && (!prompt || !(*prompt))));
  if(flag & dontread)return(0);
/* done when skip operations only were requested */

/* read a new INPUTline if needed (INPUTEOL) and permitted (skipEOL) */
  if((flag & skipEOL) && INPUTEOL)
  { if(CMDLINE)add_to_HISTORYline(INPUTline);
    CMDLINE=false;
    INPUTlen= readaline(&INPUTchpt,INPUTline,LINE_LEN,prompt);
    if(INPUTlen>0)
    { INPUTEOL=false;
      if(INPUTline[INPUTlen-1]=='\n')
      { INPUTline[--INPUTlen]='\0'; }
      INPUTpt=0;
      /* command TRACE sets ITRACE to 1, cio_menu sets it to 2 */
      /* if ITRACE is 1 or 3 echo everything */
      /* if it is 2 echo only when not in cio_program */
      if(ITRACE && ((!(ITRACE & 2)) || (!INPUTchpt)))
       sput2(">%s\n",INPUTline);
    }
    else return(errstat|EOFstat); /* end of string */
    if(flag & skipblank)
    while(INPUTpt<INPUTlen && INPUTline[INPUTpt]==' ')INPUTpt++;
  } /* end of the 'get a new line' process */
/* end of skip operations */

  c=0;
  if(INPUTpt<INPUTlen) c=INPUTline[INPUTpt];  /* get a character */
  if(c==';'
   && (! (flag & rawread))
   && (  (flag & (termEOK | termEOL | termA) ) != termEOL)
   && (! (flag & termquote)))
  {INPUTEOK=true; c=0;
  }
  else
  { /* only now increment pointer for next call */
    INPUTpt++;
    INPUTEOL=(INPUTEOL||INPUTpt>INPUTlen || c==0 || c==0x0d || c==0x0a);
    if(INPUTEOL)c=0;
    if(! (flag & termquote))
    {
      /* special case: treat space+comma as one terminator */
      if(c==' ' && (flag&termspace) && (flag&termcomma))
      { while(INPUTpt<INPUTlen && INPUTline[INPUTpt]==' ')INPUTpt++;
        if(INPUTline[INPUTpt]==',')INPUTpt++;
      }
      if(c==' ' && (flag&termspace))c=0;
      if(c==',' && (flag&termcomma))c=0;
    }
  }
#ifdef DEBUG
if(c>= ' ') sput4(
	"readchar, c=%c,  INPUTpt=%d, INPUTEOL=%d\n",c,INPUTpt,INPUTEOL);
else sput4(
	"readchar, c=%3x, INPUTpt=%d, INPUTEOL=%d\n",c,INPUTpt,INPUTEOL);
#endif /* DEBUG */
  return((int4)c);
}

/*========================  history ==========================*/

#ifndef WITH_CLE
int my_add_history(line)
char line[];
{ int i,j,hislinept=0;

  i=strlen(line);
  if(i > 0)
  {
    if(HISline >= 0) hislinept= HISlinept[HISline] + HISlen[HISline];
    if( hislinept+i >= HISchars ) hislinept=0;
    ++HISline;
    HISline %= HISlines;
    HISlinept[HISline] = hislinept;
    HISlen[HISline] = i+2;
    j=0;
    while(j < i) HISTORY[hislinept++]= line[j++];
    HISTORY[hislinept++]= '\n';
    HISTORY[hislinept++]= '\0';
    HISlineno[HISline]= HISnr;
    ++HISnr;
  }
  return 0;
}

int my_write_history(pfile)
char *pfile;
{
  FILE *logfile = NULL;
  int jfirst, i, j;

  if(HISline < 0) return 0; /* no history yet */

  if(pfile)
  { logfile = fopen(pfile,"w+");
    if (!logfile) return -1;
  }
  i= j= jfirst= HISline+1;
  while (++i != jfirst)
  { if (i >= HISlines-1) i=0;
    if( HISlinept[HISline] > HISlinept[i] &&
        HISlinept[HISline] < HISlinept[i]+HISlen[i] )
    { j=i;
    }
  }
  while (++j != jfirst)
  { if (j >= HISlines-1) j=0;
    if( HISlen[j] > 0)
    {
      if(logfile)
      fputs(&HISTORY[HISlinept[j]],logfile);
      else
      {
        sput1(&HISTORY[HISlinept[j]]);
      }
    }
  }
  if(logfile)fclose(logfile);
  return 0;
}
#endif

int history()
{
  char filename[128], *pfile=filename;
  int4 stat;

  xget_text("filename [<return>=screen]:",pfile,80,false);
  if(*pfile == '-')
  {
    HISTORY_default_substitute= (int)
    yesno("default_substitute",HISTORY_default_substitute);
    return 0;
  }
  if(!(*pfile))pfile=NULL;
  else fexpandfn(pfile);
  stat = write_history(pfile);
  if (stat) eruit("Error in saving history to %s",pfile);
  return 0;
}

/*======================== readaline =======================*/

int readaline(pointer,line,len,prompt)
int4 len;
char **pointer,line[],*prompt;
{
  register int i;
  int ii;
  register char ci;
  char *ugets();
  int prompt_gnu= false;

#ifdef WITH_CLE
  char *rawline, *expandedline;
  int4 his_stat;
#endif

  i=0;
  HISTORYdefaultentry=0; /* moved from inside if statement Jan97 PJMS */

  if(!*pointer) /* test if reading from stdin */
  { /* come here when reading from stdin.        */
    /* (keyboard, pipe (cio_menu), or file)      */

	 /* suppress prompt if stdin not interactive, */
    /* unless stdout is also not interactive.    */
    if (!( (!INTERACTIVE[0]) && INTERACTIVE[1]))
    {
#ifdef WITH_CLE
      /* gnu readline will take care of the prompt */
      if(menu_open || (!INTERACTIVE[0]))
#endif
      {
        sput1(prompt);
      }
    }
	 if(menu_open || (!INTERACTIVE[0]))
    do

    { /* come here to read from file or pipe */
      if ( ugets(line, len, stdin)) { i= strlen(line); }
      else i = -1;
    } while ( i>0 && i<3 && line[0]==HANDSHAKE );
    /* ignore line containing only HANDSHAKE character */
    else 

    { /* come here when reading from the keyboard */
#ifdef WITH_CLE
		rawline = readline(prompt);
      prompt_gnu= true;
      if(!rawline)
        return(0);
      if(!(*rawline))
      {
        HISTORYdefaultentry=1; /*substitute default in case of return */
        *line= '\n';   /* return newline char 21/07/96 PJMS */
        i=1;
      }
      else
      {
		  his_stat = history_expand(rawline,&expandedline);
        if (his_stat == -1)  /* use unexpanded line, if expansion fails */
          strcpy(expandedline,rawline);
        else if (his_stat > 0)
          { sput2(">%s\n",expandedline); }
        i = strlen(expandedline);
        if (i>LINE_LEN)
        {
          expandedline[LINE_LEN-1] = '\0';
          i=LINE_LEN;
        }
        strcpy(line,expandedline);
		  if(*line)
        {
          free(rawline);
          free(expandedline);
        }
      }
    }
#else   /* not WITH_CLE */
#ifdef MS_DOS
      i = get_line(line);
#else
      if ( ugets(line, len, stdin)) { i= strlen(line); }
      else i = -1;
#endif   /* MS_DOS */
    }
#endif   /* WITH_CLE */
    ii=i;
    if (i>0 &&(line[i-1]==EOL0 || line[i-1]==EOL1))
    {
      line[--ii]=0; /* temporarily replace EOL by 0 */
      if(ii == 0) HISTORYdefaultentry=1;
      /*substitute default in case of return */
    }
    if(ii > 0) add_to_HISTORYline(line);
    /* attach a newline char */
	 if(ii < LINE_LEN-1) { line[ii++]='\n'; i= ii; }
  }

  else while(len>0)
  { /* come here while 'reading' from cio variable */
    ci=(**pointer); 
    if(ci=='\0') break;
    ++*pointer; /* don't increment pointer past the 0 !*/
    if(ci != PADDO) /* ignore padding: remains of CRLF sequence */
    {
      line[i++]=ci;
      --len;
    }
    if(ci=='\n') break;
  }
  if(len>0 && i>=0)line[i]='\0';

  if(LOGINPUT && i>0 && !*pointer)
  { if(prompt_gnu) fput_log(prompt);
	 fput_log(line);
  }
  return(i);
}
/*=========================  cio_exit  =========================*/
int cio_exit(internal)
int internal; /* internal=0: command exit, internal=1: internal call */
{
  char c,d;
  int4 stat=0;
#ifdef CIOVARS
  extern int VARLEVEL;
#endif
  extern char *INPUTchpt;
  if(INPUTchpt)
  {
    popc(&c,1);
    switch(c)
    {
#ifdef CIOVARS
    case 'v':
      popcontext();
      if(VARLEVEL>1)--VARLEVEL;
      varcleanup(VARLEVEL);
      break;
#endif /* CIOVARS */
    case 'i':
      popc(&breakflag,1);
      cio_exit(internal);
      break;
    case 'w': case 'd': case 'r': popc(&d,1);
    default:
      stat= (errstat|illterm);
    }
  }
  if(stat<0)
  {
    eruit("illegal exit of cio program during %s",
      (c=='w')?"while":((c=='d')?"do":((c=='r')?"rep":"??")));
  }
  return (int)stat;
}
/*=========================  evalxp  =========================*/
#ifndef cio_h
#include <cio/cio.h>
#endif /* cio_h */
/* evalxp_ : decode an expression from an ASCII string   */
/* Expressions are evaluated from left to right.         */
/* Arithmetic and relational operators are               */
/*  +  -  *  /  **  >   <   >=   <=  ==  !=              */
/* There are no priority rules for these operators !!!   */
/* Brackets ( and ) may be used to group expressions     */
/* Numbers may consists of the following parts           */
/* <sign><0x><digits><.><digits><e><sign><digits><k>     */
/* where 0x means 'hexadecimal' and k means '*1024'      */
/* The following functions are available:                */
/* sin, cos, tan, asin, acos, atan, exp, ln, sqrt        */
/* The expression may contain 'runtime variables',       */
/* of type double or int4 or float.                       */
/* Assignment operators are  :=  +=  -=  *=  /=          */
/* Assignment takes place from right to left and has a   */
/* lowest priority                                       */
/*                    usage:                             */
/* stat=evalxp_(line,&len,&ipt,&ianswer,&fanswer,&term); */
/* arguments:  line (input) = string                     */
/*            *len  (input) = nr of characters in line   */
/*            *ipt (input/output) = index within line    */
/*            *ianswer (output) = result (integer)       */
/*            *fanswer (output) = result (double)        */
/*            *term (output)    = terminating character  */
/* stat:         0 = expression decoded, integer result  */
/*  notinteger     = expression decoded, not an integer  */
/*  nonumber       = no expression, terminator only      */
/*  EOString|nonumber = no expression, end of string     */
/*  delimiterr      = terminated by unmatched ] or )      */
/*  errstat|numerr = division by 0 , overflow , etc.     */
/*  errstat|syntaxerr = syntax errors                    */
/*  errstat|Qstat  = a Q or q (for quit) was encountered */
/* if no expression is decoded, ianswer and fanswer are unchanged */
/* ipt input value : index of first character to be inspected */
/*                   (0 for first character of line)          */
/* ipt output value : index of character following terminator */

static int LEVEL=0;

int4 evalxp_(text,nt,ipt,ianswer,fanswer,term)
char text[];
int4 *nt,*ipt,*ianswer,*term;
double *fanswer;
{ register int4    iop,nopr,err,flag,cnew,i1,i2,iv,len;
           int4    ivalue,istart,nfun;
  register double result,rdiff;
           double rnew;
  Varname varname;
  VARIABLE *varptr, *testvar();
  char   *valptr, *assignptr, *testrange();
  char   type='?', atype='?';

  iop=0; nopr=0; result=0; err=0; istart=(*ipt), len=(*nt);
  valptr=NULL; varptr=NULL; assignptr=NULL;
  ++LEVEL;
  if(istart >= len) err=EOString;

  while ( err >= 0 && err < EOString)
  { if (assignptr)
      flag=evalxp_(text,nt,ipt,&ivalue,&rnew,term);
    else 
    {
      flag=numget_(text,nt,ipt,&ivalue,&rnew,term);
      if(*term =='?' && flag==nonumber)
      {
        char auxtext[80], *auxj, *auxp, auxprompt[80];
        int4 auxlen=80;
        int4 auxipt=0;

        strncpy(auxprompt,&text[*ipt],79);
	auxprompt[79]= '\0';
	auxp= auxj= auxprompt;
	if(*auxp == '\'')
	{ ++auxp;
	  while(*auxj++)
	   if(*(auxj) == '\'')
	   { (*ipt)++;
	     break; /* bump to next ' */
	   }
	}
	else
	{ while(*auxj++)            /* look for ',' or ' ' */
	   if((*auxj == ' ')||(*auxj == ','))break;
	}
	*auxj='\0';
        ask_user(auxp,auxtext,80,0);
        flag=evalxp_(auxtext,&auxlen,&auxipt,&ivalue,&rnew,term);
	*ipt += strlen(auxprompt);
	*term = text[*ipt];
	if(*term) (*ipt)++;
      }
    }
    cnew=(*term);

    if (flag==nonumber)

    {
      if(cnew=='(')
      { flag=evalxp_(text,nt,ipt,&ivalue,&rnew,term); cnew=(*term);
        if( (flag&(errstat|nonumber)) || cnew!=')' )
         {err |= errstat|syntaxerr; break;}
        cnew=' '; flag&=notinteger; valptr=NULL;
      } else


      { i2=i1=(*ipt)-1; iv=1; varname[0]= (char)cnew;
        while ((++i2<len) && isalnum(text[i2]))
          if(iv<8)varname[iv++]=text[i2];
        varname[iv]='\0';
        varptr=testvar(varname);

        if(varptr)
        { --(*ipt);
          flag=evalvar(text,nt,ipt,&varptr,varname,term); cnew=(*term);
          if(flag & errstat) {err |= flag; break;}
          if(cnew != '[')
          { *term=cnew; ivalue=0;
            /* no subscript: size should not be larger then 1 element */
            if(testrange(varptr,1)){err|=(errstat|nosubscrpt);break;}
          } else
          { flag=evalxp_(text,nt,ipt,&ivalue,&rnew,term); cnew=(*term);
            if( (flag&(errstat|nonumber)) || cnew!=']' )
            {err|=errstat|syntaxerr; break;}
            cnew=' '; flag&=notinteger;
          }
          valptr=testrange(varptr,ivalue);
          if(!valptr){err=(errstat|rangerr); break;}
          type=varptr->type;
          if(type=='i'){rnew=(*(int4 *)valptr); flag=0;} else
          if(type=='d'){rnew=(*(double *)valptr); flag=notinteger;} else
          if(type=='f'){rnew=(*(float  *)valptr); flag=notinteger;}
          else { err |= (errstat|varnamerr); break;}
        } else

        {nfun=mscan(&text[i1],"SQrt/Sin/Cos/Tan/Ln/EXp/ASin/ACos/ATan");
          if(nfun>0)
			 { do { cnew= (i2>=len)? '\0' : text[i2];
               } while((i2<len) && (text[i2++]==' ')); /* skip spaces */
            *ipt=i2;
            if(cnew != '(') {*term=cnew; err=errstat|syntaxerr; break;}
            flag=evalxp_(text,nt,ipt,&ivalue,&rnew,term); cnew=(*term);
            if( (flag&(errstat|nonumber)) || cnew!=')' )
             {err=errstat|syntaxerr; break;}
            cnew=' '; flag&=notinteger; valptr=NULL;
            switch (nfun)
            { case 1: rnew=sqrt(rnew); break;
              case 2: rnew= sin(rnew); break;
              case 3: rnew= cos(rnew); break;
              case 4: rnew= tan(rnew); break;
              case 5: rnew= log(rnew); break;
              case 6: rnew= exp(rnew); break;
              case 7: rnew=asin(rnew); break;
              case 8: rnew=acos(rnew); break;
              case 9: rnew=atan(rnew); break;
              default: err=errstat|syntaxerr;
            } if(rnew!=0.0 && rnew/rnew!=1.0) err=errstat|numerr;
          }
        }
      }
    }  /* end flag==nonumber */
    else valptr=NULL;

    if ( ! ( flag & (errstat|nonumber) ) )  /* valid number decoded */
    { ++nopr; /* increment operands counter */

      /* test if leading operator,  other then '-' */
      if (nopr<=1 && iop!=0 && iop!='-'){err=errstat|syntaxerr; break;};

      if(cnew=='k') {rnew=rnew*1024.0; cnew=' ';}

      /* skip trailing spaces */
      while(cnew==' ' && *ipt < len){*term=cnew=text[*ipt]; *ipt+=1;}

      /* for relational expressions,(relative_difference < EPS)=0 */
      rdiff=fabs(result)+fabs(rnew);
      if(rdiff) rdiff = (result-rnew)/rdiff;
      if(fabs(rdiff) < EPS) rdiff = 0.0;

     /* process operator */
      switch(iop)
      { case 0:   if (nopr > 1) err=errstat|syntaxerr; /* no break */
        case ':': result  = rnew; break;
        case '+': result += rnew; break;
        case '-': result -= rnew; break;
        case '*': result *= rnew; break;
        case '/': result /= rnew; break;
        case '*'*256L+'*': result = pow(result,rnew); break;
        case '>':         result = (rdiff >  0); break;
        case '<':         result = (rdiff <  0); break;
        case '>'*256L+'=': result = (rdiff >= 0); break;
        case '<'*256L+'=': result = (rdiff <= 0); break;
        case '='*256L+'=': result = (rdiff == 0); break;
        case '!'*256L+'=': result = (rdiff != 0); break;
        default: err=errstat|operanderr;
      };

/* HAVE_ISNAN should be defined if isnan and isinf are implemented */
/* Otherwise QUITFPERR may be defined, for systems where
 * float division by 0 causes a program interrupt
 */
#ifdef HAVE_ISNAN
      if(isnan(result)||isinf(result))err=errstat|numerr;
#else
#ifndef QUITFPERR
      if(1.0/result == 0.0)err=errstat|numerr;
#endif /* QUITFPERR */
#endif /* HAVE_ISNAN */
      iop=0; if ( err&errstat ) break;

      if(assignptr)
      { /* assign result to variable */
        if ( atype=='i' ) {*(int4 *)assignptr=n_int(result);} else
        if ( atype=='d' ) {*(double *)assignptr=result;} else
        if ( atype=='f' ) {*(float  *)assignptr=result;}
        else {err |= (errstat|syntaxerr); break;}
      }
    assignptr=NULL;
    } /* end number decoded */

    if ( flag>=0 && (flag&EOString)==0 )
    /* inspect terminator */
    switch(cnew)
    { case '=': if(iop==':' || iop=='+' || iop=='-' || iop=='*'
                || iop=='/' )
                { if(assignptr || !valptr) err|=(errstat|operanderr);
                  assignptr=valptr; atype=type; break;
                }
                /* else no break !! */
      case '+': case '-': case '*': case '/':
      case '<': case '>': case '!': case ':':
             if (iop > 256) err=errstat|syntaxerr;
             else iop=iop*256L+cnew; break;
      case ')': case ']': err|=delimiterr; break;
      case 'q': case 'Q': err=errstat|Qstat; break;
      case '\0': err|= EOString;
      case ' ': case (char)10: case (char)13: break;
      default: err |= illterm;
    } /* end inspect terminator */

    err|=flag;
#ifdef DEBUG
	sput3("evalxp: intermediate result %20g, err= %8lx\n",result,err);
#endif /* DEBUG */
  }; /* end while */

  --LEVEL;
  if(iop != 0) err |= (errstat|syntaxerr);
  if(nopr == 0) err |= nonumber; else
  { err &= ~nonumber; /*wipe out nonumber bit */
    if (err >= 0)
    { if (err <= (EOString|notinteger)) err=0;
      *fanswer=result;
      *ianswer= ivalue= n_int(result);
      if ( fabs(result-ivalue) > fabs(result)*EPS) err|=notinteger;
#ifdef DEBUG
      sput1("evalxp: ");
      while(istart<(*ipt))
      { sput2("%c",text[istart]);
        istart++;
      }
      putout();
      sput2(" = %20g    ",result);
#endif /* DEBUG */
    }
  };
  if(!LEVEL && (err&delimiterr))err|=errstat;
  if(err&illterm)err|=errstat;
#ifdef DEBUG
  sput3("LEVEL:%2d   stat=%lx\n",LEVEL,err);
#endif /* DEBUG */
  return(err);
}
/*=========================  numget  =========================*/
#ifndef cio_h
#include <cio/cio.h>
#endif /* cio_h */
int4 numget_ (line,len,ipt,ianswer,fanswer,term)
char line[];
int4 *len, *ipt, *ianswer, *term;
double *fanswer;
/* usage: stat= numget_(line,&len,&ipt,&ianswer,&fanswer,&term); */
/* decode a number from an ASCII string */
/* format {spaces}{sign}{0x}{digits}{.}{digits}{e}{sign}{digits} */
/* where:    0      1     2    3     4    5     6   7      8     */
/* arguments:  line (input) = string                    */
/*            *len  (input) = nr of characters in line  */
/*            *ipt (input/output) = index within line   */
/*            *ianswer (output) = result (integer)      */
/*            *fanswer (output) = result (double)       */
/*            *term (output)    = terminating character */
/* stat:         0 = number decoded, both results O.K.  */
/*      notinteger = number decoded, not an integer     */
/*      nonumber   = no number, terminator only         */
/*      EOString   = no number, end of string           */
/*  errstat|numerr = not a number, real overflow        */
/* if no number is decoded, ianswer and fanswer are unchanged */
/* ipt input value : index of first character to be inspected */
/*                   (0 for first character of line)          */
/* ipt output value : index of character following terminator */
{ int4 ch,ibase,where,sign,esign,pot,epot,finale,i,digit,inumber,flag;
  double number,base;
  extern double dxxi();
  finale=0;
  ibase=10; base=ibase;
  where=0;
  number=0;
  sign=1; esign=1; pot=0; epot=0;
  i= *ipt; *term=0;
  while ( ! finale )
  { ch=0;
    finale = (i >= *len); if (finale) { *ipt=i; *term=0; break; }
    ch=line[i++];
    switch(where)
    { case 0: case 3: case 5: case 8: *term=ch; *ipt=i;
    }; /* transfer terminator only if preceding char was space or digit */
    if (ch >= 'a' && ch <= 'z') ch+=('A'-'a');
    digit= ch; if(digit <= '9') digit -= '0';
    if (ch >= 'A') digit= ch - 'A' +10;
    if ( digit >= 0 && digit < ibase)
    { if (where < 3) where=3;
      else if (where == 4) where=5;
      if (where == 5) pot=pot-1;
      if (where < 6) number=number*base + digit;
      else
      { where=8;
        epot=epot*ibase+digit;
      };
    } else
    switch (ch)
    { case ' ': if (where != 0) finale=1;
                break;
      case '+':
      case '-': if (where == 0)
                { where=1;
                  if (ch == '-') sign= -1;
                } else
                { if (where == 6)
                  { where=7;
                    if (ch == '-') esign= -1;
                  } else
                    finale=1;
                };
                break;
      case 'X': if (where != 3 || number != 0) finale=1;
                else
                { base=ibase=16;
                  where=2;
                };
                break;
      case '.': if (where >= 4) finale=1;
                else where=4;
                break;
      case 'E': if (where >= 6 || where <= 2) finale=1;
                else where=6;
                break;
      default:  finale=1;
    };
  };
  flag=0;
  if (where < 2) flag=nonumber;
  if (where == 2) flag=errstat|syntaxerr;
  if (where == 0 && ch==0) flag|=EOString;
  if (flag == 0)
  { if (esign > 0) pot=pot+epot;
    else           pot=pot-epot;
    number=number*dxxi(base,pot);
    if (ibase == 16 && number >= twoxx31 && number < twoxx32)
         number=number - twoxx32;
    if (sign < 0) number= -number;
    *fanswer= number;
    *ianswer= inumber= n_int(number);
    if (fabs(number-inumber) > fabs(number)*EPS) flag=notinteger;
/* HAVE_ISNAN should be defined if isnan and isinf are implemented */
/* Otherwise QUITFPERR may be defined, for systems where
 * float division by 0 causes a program interrupt
 */
#ifdef HAVE_ISNAN
      if(isnan(number)||isinf(number))flag=errstat|numerr;
#else
#ifndef QUITFPERR
    if(1.0/number == 0.0)flag=errstat|numerr;
#endif /* QUITFPERR */
#endif /* HAVE_ISNAN */
#ifdef DEBUG
     sput1("numget: ");
     putout();
     sput2(" = %20g\n",number);
#endif /* DEBUG */
  }
#ifdef DEBUG
  sput3("numget: stat=%lx  term=%lx\n",flag, *term);
#endif /* DEBUG */
  return(flag);
}
/*=========================  testrange  =========================*/

/* testrange: input pointer to descriptor, return pointer to variable */
/*            offset (input) is displacement in array index units     */
/*            if offset is out of range the nil pointer is returned   */
/*            used by evalxp */
char *testrange(varptr,offset)
VARIABLE *varptr;
unsigned int4 offset;
{
  if(!varptr)return(NULL);
  if(varptr->type=='i')offset *=sizeof(int4); else
  if(varptr->type=='d')offset *=sizeof(double); else
  if(varptr->type=='f')offset *=sizeof(float); else
  if(varptr->type=='v')offset *=sizeof(Varname);
  return( (offset >= varptr->size) ? NULL : varptr->valpt + offset );
}
/*=========================  testvar  =========================*/

/* testvar: input variable name, return pointer to descriptor */
/* differences with function 'existvar':
   varname must be a string, terminated with a binary zero
   parameters minlevel and maxlevel are absent */
VARIABLE *testvar(varname)
Varname varname;
/* used by evalxp */
{
  VARIABLE *varlink;
  varlink=VARLINK;
  while (varlink)
  { if(strcmp(varlink->name,varname)==0)break;
    varlink=varlink->next;
  }
  return(varlink);
}
/*=========================  mscan  =========================*/

int mscan(key,options)
char key[],options[];
/* compare key with the list of mnemonics present in options */
/* key is terminated by any non-alphanumeric character */
/* mnemonics in options are separated by a non-alphanumeric */
/* the list is terminated by two such characters, or '\0'   */
/* required characters in CAPITALS, optional characters lower case */
/* The procedure is not sensitive to the case of characters of key */
/* return order number in options if match is found (1 for first item)*/
/*        -1 if no match is found */
/*         0 if key is empty      */
{ register int len,nopt,i,j,match,ci,cj;
  register int aminA='a'-'A';
  len= -1; while ( isalnum(key[++len]) );
  nopt=1; i=0; j=0; match=true;
  while (len)
  { cj=options[j++];
    if(isalnum(cj))
    { if(match)
      { if(i < len)
        { ci=key[i++];
          if (isupper(ci)) ci += aminA;
          if (isupper(cj)) cj += aminA;
          match=(ci==cj);
        } else
          match=islower(cj);
      }
    } else
    { match= match && (i==len);
      if (match) return (nopt); /* return when match found */
      if (i==0 || cj==0) return (-1); /* no match */
      i=0; ++nopt; match=true;
    }
  } return(0); /* return if key is empty */
}
/*=========================  cscan  =========================*/

int cscan(key,list)
char key[];  COMMAND list[];
/* compare argument key with entries in list[nopt].keyword */
/* return nopt+1 when a match is found */
/*        -1 when no match is found, 0 when key is empty */
{ register int len,nopt,i,j,match,ci,cj;
  register int aminA='a'-'A';
  len=(-1); while (key[++len]); /* key is string, terminated by '\0' */
  if(!len) return(0); /* return if key is empty */
  nopt=0; i=0; j=0; match=true;
  while (list[nopt].keyword)
  { cj=list[nopt].keyword[j++];
    if(cj)
    { if(match)
      { if(i < len)
        { ci=key[i++];
          if (isupper(ci)) ci += aminA;
          if (isupper(cj)) cj += aminA;
          match=(ci==cj);
        } else
          match=islower(cj);
      }
    } else
    { match= match && (i==len) && (list[nopt].function);
      ++nopt;
      if (match) return (nopt); /* return when match found */
      i=0; j=0; match=true;
    }
  }
  return (-1); /* no match */
}
/*=========================  dxxi  =========================*/
double dxxi(d,i) /* return d to the power i */
double d; int4 i;
{ register double r,t;
  register int4 j;
  if (i < 0) {j=(-i); t=1.0/d;}
  else       {j= i; t=    d;};
  r=1.0;
  while (j > 0)
  {if (j % 2)r*=t;
   j=(j>>1); t*=t; };
  return(r);
}
/*=========================  nint  =========================*/

int4 n_int(x) double x;
/* round x to nearest integer. OS9 does not have "nint"! */
{ register int4 ix;
  if (x >= twoxx31) ix= 0x7fffffffL;
  else if (x < -twoxx31) ix= 0x80000000L;
  else ix = (int4)((x < 0.0) ? x-0.5 : x+0.5);
  return(ix);
}
/*=========================  evalvar  =========================*/
#ifndef cio_h
#include <cio/cio.h>
#endif /* cio_h */

int4 evalvar(text,nt,ipt,V,name,term)
char text[];
Varname name;
int4 *nt,*ipt,*term;
VARIABLE **V;
/* decode a pointer to a variable from an ASCII string.    */
/* If a reference to a varlist member is encountered,      */
/* ( i.e. varlist_name[subscript]),                        */
/* this reference is resolved, and the finally returned    */
/* pointer *V points to a variable of type c,i,d, or f.    */
/* text, nt, ipt, and term have the same roles as in evalxp_ */
/* The return value should be checked for errors.          */
/* ipt is only updated when a variable is found.           */
/* The parameter name is set to the final name decided on. */
/* If no corresponding variable of type c,i,d, or f exists */
/* the return status is  set to (errstat|undefined).       */
/* If text contains an unsubscripted variable name of      */
/* type 'v' the return value is (errstat|nosubscrpt),      */
/* but V and name are valid (contrary to earlier versions).*/
{ register int4 err=0,flag=0,len;
  register int i2,iv;
  int4 istart;
#ifdef CIOVARS
  int4 cnew=0;
  int4 ivalue;
  double rnew;
  char *valptr;
#endif
  VARIABLE *varptr;

#ifdef DEBUGv
  char termstr[8];
#endif /* DEBUGv */

  istart=(*ipt);
  len=(*nt);
#ifdef CIOVARS
  valptr=NULL;
#endif
  varptr=NULL;
  if(istart >= len) err=EOString;

  if ( err >= 0 && err < EOString) /* err >=0 means no fatal error */
  { i2=(*ipt); iv=0;
    while ((i2<len) && (text[i2]==' ')) ++i2; /* skip spaces */
    while ((i2<len) && isalnum(text[i2]))
      { if(iv<8)name[iv++]=text[i2]; ++i2; }
    name[iv]='\0';
#ifdef CIOVARS
    varptr=testvar(name);

    if(varptr)
    {
      while(varptr->type == 'v')
      { while ((i2<len) && (text[i2]==' '))++i2; /* skip spaces */
        *term = cnew = (i2>=len)? '\0' : text[i2];
        *ipt=i2+1;
        ivalue=0;
        /* process subscript only if size is larger than 1 !! */
        if(testrange(varptr,1))
        { if(cnew != '[')
          { /* no subscript: size should not be larger then 1 element */
            err|=(errstat|nosubscrpt);break;
          } else
          { flag=evalxp_(text,nt,ipt,&ivalue,&rnew,term); cnew=(*term);
            if( (!((flag&(~errstat))==delimiterr)) || (cnew!=']') )
            {err|=errstat|syntaxerr; break;}
            cnew=' '; flag&=notinteger;
            i2=(*ipt);
          }
        }
        valptr=testrange(varptr,ivalue);
        if(!valptr){err=(errstat|rangerr); break;}
        varptr = testvar(valptr);
        strncpy(name,valptr,9);
        if(!varptr)
        {flag |= (errstat|undefined);
         break;
        }
      }
      varptr=testoverlap(varptr);
      if(i2 < len) {*ipt=i2+1; *term=text[i2];}
      else {*ipt=len; *term=0;}

    }
#else
    varptr=NULL;
#endif
    if(!varptr) err|=(errstat|undefined);
    err|=flag;
  }
  if (err >= 0)
  { if (err <= (EOString|notinteger)) err=0;
    if((err&delimiterr))err|=errstat;
  }
  *V= (err >= 0 || err==(errstat|nosubscrpt))? varptr : NULL;
#ifdef DEBUGv
  sput1("evalvar: ");
  for(;istart<(*ipt);istart++)
  { sput2("%c",text[istart]); }
  if(*V) sput2("--> %8s  ",varptr->name);
  if(*term >= ' ' && *term <= '~')
  { termstr[0]= *term; termstr[1]= '\0'; }
  else sprintf(termstr,"\\%1x\0",*term);
  sput4(" stat=%x, ipt=%d, term='%s'\n",err,*ipt,termstr);
#endif /* DEBUGv */
  return(err);
}

#ifdef WITH_CLE

/*========================== Command completion ===========================*/

/* This code has been taken from the example program fileman.c from the 
   GNU readline-2.0 library distribution */

char *command_generator ();
char **fileman_completion ();

extern char *xmalloc();

char *dupstr(s)
     char *s;
{
  char *r;
  r = xmalloc (strlen(s)+1);
  strcpy(r,s);
  return(r);
}

/* Tell the GNU Readline library how to complete.  We want to try to complete
   on command names if this is the first word in the line, or on filenames
   if not. */

int initialize_readline ()
{
  /* Allow conditional parsing of the ~/.inputrc file. */

  strcpy(rl_readline_name,PROGRAMNAME);

  /* Tell the completer that we want a crack ourselves first. */

  rl_attempted_completion_function = (CPPFunction *)fileman_completion;
  return 0;
}

/* Attempt to complete on the contents of TEXT.  START and END show the
   region of TEXT that contains the word to complete.  We can use the
   entire line in case we want to do some simple parsing.  Return the
   array of matches, or NULL if there aren't any. */

char **fileman_completion (text, start, end)
     char *text;
     int4 start, end;
{
  char **matches;

  matches = (char **)NULL;

  /* If this word is at the start of the line, then it is a command
     to complete.  Otherwise it is the name of a file in the current
     directory. */

  if (start == 0)
    matches = completion_matches (text, command_generator);
  return (matches);
}

/* Generator function for command completion.  STATE lets us know whether
   to start from scratch; without any state (i.e. STATE == 0), then we
   start at the top of the list. */

#include <ctype.h>
char *command_generator (text, state)
     char *text;
     int4 state;
{
  extern COMMAND command[];
  static int4 list_index, len,i;
  char *name, lowername[LINE_LEN];

  /* If this is a new word to complete, initialize now.  This includes
     saving the length of TEXT for efficiency, and initializing the index
     variable to 0. */

  if (!state)
    {
      list_index = 0;
      len = strlen (text);
    }

  /* Return the next name which partially matches from the command list. */

  while (name = command[list_index].keyword)
    {
      for(i=0;i<strlen(name);i++)
   lowername[i] = tolower(name[i]);
      lowername[strlen(name)] = '\0';
      list_index++;
      if (strncmp(lowername, text, len) == 0)
     return (dupstr(lowername));
    }
  /* If no names matched, then return NULL. */
  return ((char *)NULL);
}
#endif

#include <cio/cio.h>

void error()
{
  /* come here on input error */
  printf("AN INPUT ERROR OCCURRED\n");
  exit(1);
}

int main()
{
  char* line="atan(1)*4";
  int4 ianswer;
  double fanswer;
  int4 term, ipt=0, len, stat;

  ciobeg(error);
  len=strlen(line)+1;
  stat= evalxp_(line, &len, &ipt, &ianswer, &fanswer, &term);
  printf("stat=%x, line= %s, ianswer=%d, fanswer = %f\n",
    stat, line, ianswer, fanswer);
  intarg(&ianswer,"type an integer:", 16);
  printf("the number was %d\n",ianswer);
  return 0;
}

/* @(#)misc.c           02/06/97 20:23:45 */
#ifndef cio_h
#include <cio/cio.h>
#endif /* cio_h */
/*=========================  stept  =========================*/
int stept()
{ ISTEP = (char) yesno("enable STEP?",true); return(0); }
/*=========================  cio_stop  =========================*/
int cio_stop()
{ extern void exit();
  sput2(" ... program %s quitting ...\n",PROGRAMNAME);
  newline();
  exit(0);
}
/*=========================  trace  =========================*/
int trace()
{ ITRACE = (char) yesno("enable TRACE?",true); return(0); }
/*=========================  erin  =========================*/
#ifndef cio_h
#include <cio/cio.h>
#endif /* cio_h */
int erin() /* continue after an error exit via eruit */
{ extern int ercontext,ercontrolpt;
  if(ercontext > 1)
  { rstcontext(ercontext);
    controlpointer=ercontrolpt;
    popc(&breakflag,1);
  }
  else { sput1("can't continue\n"); }
  ercontext= -1;
  longjmp(environment,-1);
  return(0);
}
/*=========================  printerr  =========================*/
CIO_ERR cio_err[]=
{ {errstat,"\007?"},
  {nonumber,"number expected"},
  {EOString,"empty string"},
  {delimiterr,"extra ] or )"},
  {numerr,"numerical error"},
  {syntaxerr,"syntax error"},
  {varnamerr,"bad variable name"},
  {conflict,"name or type conflict"},
  {operanderr,"illegal operand"},
  {truncaterr,"text truncated"},
  {filerr,"file error"},
  {rangerr,"out of range"},
  {nosubscrpt,"subscript missing"},
  {undefined,"variable undefined"},
  {illterm,"illegal terminator"},
  {readerr,"read error"},
  {writerr,"write error"},
  {formaterr,"error in file format"},
  {notfoundr," .. not found"},
  {EOFstat ,"end of file"},
  {0,""}
};

char *printerr(stat) int4 stat;
/* print error messages depending on bits in stat */
{ 
  static char errmess[LINE_LEN];
  register int ier;
  errmess[0]= '\0';
  if(stat)
  { for(ier=0;cio_err[ier].nr;++ier)
    if((stat&cio_err[ier].nr))
    {
      strcat(errmess,cio_err[ier].message);
      strcat(errmess,"! ");
    }
    strcpy(OUTPUTline,errmess);
    newline();
  }
  return errmess;
}
/*========================== xprinterr    =====================*/
void xprinterr(stat) int4 stat;
{
  if(stat)
  { if(stat&errstat)eruit(" %s",printerr(stat));
    if(!(stat&Qstat))printerr(stat);
  }
}
/*=========================  iselect  ==========================*/
#ifndef cio_h
#include <cio/cio.h>
#endif /* cio_h */
int iselect(text,ntext)
char text[];
int ntext;
/* ask for a text argument (via get_text), using as prompt a list */
/* of options present in text.                                   */
/* Options are to be separated by a single non-alphabetic character. */
/* Required letters in capitals, optional letters in lower case. */
/* The text argument is compared with the options list, via mscan, */
/* and the order number in the options list is returned.         */
/* More specifically, return value              */
/* > 0 : a match was found                      */
/*  0  : an empty argument was input            */
/* -1  : a non-matching argument was input      */
/* Fortran call (example):                      */
/*    GOTO(301,305,306,308),ISELECT('Sp/Ivar/Rvar/TERmnl/: ') */
/*    CALL ERUIT_('Illegal option')                           */

{ char response[12],*pp;
  pp = sprompt(text,ntext);
  if ( get_text(pp,response,12,false) & errstat )
  eruit("iselect: input error\n",NULL);
  return( mscan(response,pp));
}
/*=========================  iselect1 ==========================*/
int iselect1(text,promptflag,ntext)
char text[];
int *promptflag,ntext;
/* same effect as iselect when *promptflag is non-zero  */
/* else, no prompt is issued, which implies that only   */
/* the current line is scanned for the response         */

{ char response[12],*pp;
  pp = sprompt(text,ntext);
  if ( get_text((*promptflag)?pp:NULL,response,12,false) & errstat )
  eruit("iselect: input error\n",NULL);
  return( mscan(response,pp));
}

int cselect(text)
char text[];
/* iselect for C applications. parameter ntext is not needed */
{ return (iselect(text,-1));
}

int cselect1(text,promptflag)
char text[]; int promptflag;
/* iselect1 for C applications. parameter ntext is not needed */
/* promptflag is an int, not a pointer to an int */
{ return (iselect1(text,&promptflag,-1));
}

int cselect2(text,promptflag,response)
char text[], response[12]; int promptflag;
/* a variation that also returns the response */
{ char *pp;
  pp = sprompt(text,-1);
  if ( get_text((promptflag)?pp:NULL,response,12,false) & errstat )
  eruit("cselect2: input error\n",NULL);
  return( mscan(response,pp));
}
/*======================== sprompt =======================*/
char *sprompt(prompt,nprompt) char *prompt; int nprompt;
/* Translate Fortran prompt into C prompt, i.e. */
/* copy prompt, append a '\0', and return pointer. */
/* Stop when nprompt characters are copied, or, */
/* a null character is encountered, or, */
/* LINE_LEN-2 characters are copied, whichever happens first. */
{ static char cstring[LINE_LEN];
  register int i,j;
  i = 0;
  if (nprompt)
  do { cstring[i] = j = *prompt++;
     } while ( (i++ < LINE_LEN-2) && (--nprompt) && (j) );
  cstring[i] = '\0';
  return (cstring);
}

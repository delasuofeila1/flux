#!/bin/sh

#run program show
./BIN/show ./bigjob.flx <<DONE
both
bigshow.ps
Cursor
yield
0 1
1 1 1 2 3 -5
1 1 2 1 3 -1
1 1 3 1 3 -2
1 1 4 1 3 -3
1 1 5 1 3  0
1 2 1 1 3 -5
1 2 2 1 3 -1
1 2 3 1 3  0
-2
dE/x
0 0
1 1 1 2 3 -5
1 1 2 1 3 -1
1 1 3 1 3 -2
1 1 4 1 3 -3
1 1 5 1 3  0
1 2 1 2 3 -5
1 2 2 1 3 -1
1 2 3 1 3  0
-2
strag
0 0
1 3 1 2 3 -5
1 3 2 1 3 -1
1 1 3 1 3 -2
1 1 4 1 3 -3
1 1 5 1 3  0
1 2 3 1 3  0
-2
end
DONE
